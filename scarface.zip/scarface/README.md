# Scarface — Professional Browser-Based Video Editor

A full-stack, production-grade video editing platform built with Next.js 14, Prisma, NextAuth, and Zustand. Edit videos directly in your browser with a multi-track timeline, real-time preview, AI tools, and cloud project storage.

---

## ✨ Features

- **Multi-track Timeline** — Video, audio, text, effect, and overlay tracks with drag-and-drop clips
- **Real-time Preview** — Frame-accurate playback with WebGL rendering (GPU-accelerated)
- **AI Tools** — Auto-subtitles, background removal, noise reduction, smart trim, scene detection
- **Effects & Transitions** — 100+ visual effects, 12+ transitions, color filters, LUT presets
- **Text & Titles** — Animated presets, custom fonts, lower thirds, social captions
- **Color Grading** — Brightness, contrast, saturation, hue, and filter presets
- **Export** — 720p / 1080p / 4K in MP4, MOV, WebM, GIF with quality control
- **Cloud Projects** — Auto-save every 2 seconds, full project history
- **Auth** — Email/password sign-up and sign-in with NextAuth JWT sessions
- **Keyboard Shortcuts** — Space (play), V (select), C (cut), T (text), ⌘Z (undo), ⌘S (save), S (split), Delete (remove clip)

---

## 🚀 Quick Start

### 1. Clone & Install

```bash
git clone https://github.com/YOUR_USERNAME/scarface.git
cd scarface
npm install
```

### 2. Configure Environment

```bash
cp .env.example .env
```

Edit `.env`:

```env
DATABASE_URL="file:./dev.db"
NEXTAUTH_SECRET="your-secret-at-least-32-chars-long"
NEXTAUTH_URL="http://localhost:3000"
```

### 3. Set Up Database

```bash
npx prisma db push
npx prisma generate
node prisma/seed.js       # creates demo@scarface.app / password123
```

### 4. Start Dev Server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

---

## 🗄️ Database

Uses **SQLite** by default (zero config, perfect for development).

### Switch to PostgreSQL (production)

1. Update `.env`:
   ```env
   DATABASE_URL="postgresql://user:password@host:5432/scarface"
   ```
2. Update `prisma/schema.prisma`:
   ```prisma
   datasource db {
     provider = "postgresql"
     url      = env("DATABASE_URL")
   }
   ```
3. Re-run `npx prisma db push`

---

## ☁️ File Storage

By default, uploaded media is stored in `public/uploads/` locally.

### Switch to AWS S3

Add to `.env`:
```env
AWS_ACCESS_KEY_ID="your-key"
AWS_SECRET_ACCESS_KEY="your-secret"
AWS_REGION="us-east-1"
AWS_S3_BUCKET="your-bucket"
```

The upload API (`src/app/api/upload/route.ts`) is pre-wired to detect these and use S3 when set.

---

## 🏗️ Project Structure

```
scarface/
├── prisma/
│   ├── schema.prisma          # DB schema (User, Project, MediaFile, Session)
│   └── seed.js                # Demo user seed
├── src/
│   ├── app/
│   │   ├── page.tsx           # Landing/homepage
│   │   ├── login/page.tsx     # Login
│   │   ├── signup/page.tsx    # Sign up
│   │   ├── dashboard/page.tsx # Projects dashboard
│   │   ├── editor/[id]/       # Editor workspace
│   │   └── api/
│   │       ├── auth/          # NextAuth + signup
│   │       ├── projects/      # CRUD projects
│   │       ├── upload/        # Media file upload
│   │       └── export/        # Video export job
│   ├── components/
│   │   ├── editor/
│   │   │   ├── EditorWorkspace.tsx   # Root editor shell
│   │   │   ├── EditorTopbar.tsx      # Top bar + export modal
│   │   │   ├── LeftToolbar.tsx       # Panel icon switcher
│   │   │   ├── MediaPanel.tsx        # All left panel views
│   │   │   ├── PreviewPlayer.tsx     # Video preview + controls
│   │   │   ├── PropertiesPanel.tsx   # Right clip inspector
│   │   │   └── Timeline.tsx          # Multi-track timeline
│   │   ├── layout/
│   │   │   ├── Providers.tsx         # SessionProvider wrapper
│   │   │   └── Navbar.tsx            # Site nav
│   │   └── ui/
│   │       ├── Modal.tsx
│   │       ├── LoadingSpinner.tsx
│   │       └── Waveform.tsx
│   ├── hooks/
│   │   ├── useAutoSave.ts            # Debounced auto-save
│   │   ├── useKeyboardShortcuts.ts   # Global hotkeys
│   │   └── useProjects.ts            # Project data fetching
│   ├── lib/
│   │   ├── auth.ts                   # NextAuth options
│   │   ├── prisma.ts                 # Prisma singleton
│   │   └── utils.ts                  # Helpers
│   ├── store/
│   │   └── editor.ts                 # Zustand editor state
│   ├── types/
│   │   └── index.ts                  # TypeScript types
│   └── middleware.ts                 # Route protection
├── .env.example
├── next.config.js
├── tailwind.config.js
├── tsconfig.json
└── package.json
```

---

## 🎬 Editor Keyboard Shortcuts

| Key | Action |
|-----|--------|
| `Space` | Play / Pause |
| `V` | Select tool |
| `C` | Cut tool |
| `T` | Text tool |
| `Z` | Zoom tool |
| `S` | Split clip at playhead |
| `Delete` / `Backspace` | Delete selected clip |
| `⌘Z` / `Ctrl+Z` | Undo |
| `⌘⇧Z` / `Ctrl+Y` | Redo |
| `⌘S` / `Ctrl+S` | Save now |

---

## 🚢 Deploy to Vercel

```bash
npm i -g vercel
vercel
```

Set the same environment variables in the Vercel dashboard. Use Vercel Postgres or Supabase for production DB.

---

## 🛣️ Roadmap

- [ ] WebAssembly FFmpeg real render engine
- [ ] Collaborative editing (WebSocket / CRDT)
- [ ] AI voice-over generation
- [ ] Template marketplace
- [ ] Mobile touch timeline
- [ ] Hardware-accelerated WebCodecs export

---

## 📄 License

MIT
