/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    remotePatterns: [
      { protocol: 'https', hostname: '**.amazonaws.com' },
      { protocol: 'https', hostname: 'scarface.app' },
    ],
    unoptimized: process.env.NODE_ENV === 'development',
  },
  // Allow large file uploads
  experimental: {
    serverComponentsExternalPackages: ['@prisma/client', 'bcryptjs', 'sharp'],
  },
  // Increase body size limit for video uploads
  api: {
    bodyParser: false,
  },
}

module.exports = nextConfig
