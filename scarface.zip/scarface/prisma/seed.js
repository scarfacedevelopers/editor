const { PrismaClient } = require('@prisma/client')
const bcrypt = require('bcryptjs')
const { v4: uuid } = require('uuid')

const prisma = new PrismaClient()

async function main() {
  console.log('🌱 Seeding database...')

  const passwordHash = await bcrypt.hash('password123', 12)

  const user = await prisma.user.upsert({
    where:  { email: 'demo@scarface.app' },
    update: {},
    create: {
      email:    'demo@scarface.app',
      name:     'Demo User',
      password: passwordHash,
    },
  })

  console.log(`✅ Demo user: ${user.email} / password123`)

  // Create a sample project
  const defaultTimeline = {
    tracks: [
      { id: uuid(), type: 'video',  name: 'Video 1',  muted: false, solo: false, clips: [], volume: 1, color: '#6c5ce7' },
      { id: uuid(), type: 'video',  name: 'Video 2',  muted: false, solo: false, clips: [], volume: 1, color: '#a29bfe' },
      { id: uuid(), type: 'audio',  name: 'Audio 1',  muted: false, solo: false, clips: [], volume: 1, color: '#00b894' },
      { id: uuid(), type: 'text',   name: 'Captions', muted: false, solo: false, clips: [], volume: 1, color: '#fdcb6e' },
      { id: uuid(), type: 'effect', name: 'Effects',  muted: false, solo: false, clips: [], volume: 1, color: '#e17055' },
    ],
    duration: 120,
    fps: 30,
  }

  const project = await prisma.project.upsert({
    where:  { id: 'demo-project-1' },
    update: {},
    create: {
      id:         'demo-project-1',
      name:       'My First Project',
      resolution: '1080p',
      fps:        30,
      status:     'draft',
      timeline:   JSON.stringify(defaultTimeline),
      settings:   '{}',
      userId:     user.id,
    },
  })

  console.log(`✅ Demo project: "${project.name}"`)
  console.log('\n🎬 Seed complete! Visit http://localhost:3000 to get started.')
}

main()
  .catch(e => { console.error('❌ Seed failed:', e); process.exit(1) })
  .finally(() => prisma.$disconnect())
