import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const userId = session.user.id

  const { projectId, resolution, format, quality, fps } = await req.json()
  if (!projectId) return NextResponse.json({ error: 'projectId required' }, { status: 400 })

  const project = await prisma.project.findFirst({ where: { id: projectId, userId } })
  if (!project) return NextResponse.json({ error: 'Project not found' }, { status: 404 })

  // Mark project as rendering
  await prisma.project.update({
    where: { id: projectId },
    data: { status: 'rendering', resolution: resolution ?? project.resolution },
  })

  // In production this would enqueue a render job (FFmpeg/cloud worker).
  // For demo we simulate completion after a delay by returning a job token.
  const jobId = `job_${Date.now()}_${Math.random().toString(36).slice(2)}`

  // Simulate async completion – mark exported after 5 seconds
  setTimeout(async () => {
    await prisma.project.update({
      where: { id: projectId },
      data: { status: 'exported' },
    }).catch(() => {})
  }, 5000)

  return NextResponse.json({
    jobId,
    message: 'Export started. Your video will be ready shortly.',
    settings: { resolution, format, quality, fps },
  })
}

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const { searchParams } = new URL(req.url)
  const projectId = searchParams.get('projectId')
  if (!projectId) return NextResponse.json({ error: 'projectId required' }, { status: 400 })
  const project = await prisma.project.findFirst({
    where: { id: projectId, userId: session.user.id },
    select: { status: true },
  })
  return NextResponse.json({ status: project?.status ?? 'unknown' })
}
