import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { unlink } from 'fs/promises'
import { join } from 'path'

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { searchParams } = new URL(req.url)
  const projectId = searchParams.get('projectId')
  if (!projectId) return NextResponse.json({ error: 'projectId required' }, { status: 400 })

  const project = await prisma.project.findFirst({
    where: { id: projectId, userId: session.user.id },
  })
  if (!project) return NextResponse.json({ error: 'Not found' }, { status: 404 })

  const files = await prisma.mediaFile.findMany({
    where: { projectId },
    orderBy: { createdAt: 'desc' },
  })

  return NextResponse.json({
    files: files.map(f => ({ ...f, createdAt: f.createdAt.toISOString() })),
  })
}

export async function DELETE(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { mediaId } = await req.json()
  if (!mediaId) return NextResponse.json({ error: 'mediaId required' }, { status: 400 })

  const media = await prisma.mediaFile.findUnique({
    where: { id: mediaId },
    include: { project: { select: { userId: true } } },
  })
  if (!media || media.project.userId !== session.user.id)
    return NextResponse.json({ error: 'Not found' }, { status: 404 })

  // Delete local file if it exists
  if (media.url.startsWith('/uploads/')) {
    try {
      await unlink(join(process.cwd(), 'public', media.url))
    } catch {
      // File may already be gone — continue
    }
  }

  await prisma.mediaFile.delete({ where: { id: mediaId } })
  return NextResponse.json({ success: true })
}
