import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const source = await prisma.project.findFirst({
    where: { id: params.id, userId: session.user.id },
  })
  if (!source) return NextResponse.json({ error: 'Not found' }, { status: 404 })

  const copy = await prisma.project.create({
    data: {
      name:       `${source.name} (copy)`,
      description:source.description ?? undefined,
      duration:   source.duration,
      resolution: source.resolution,
      fps:        source.fps,
      status:     'draft',
      timeline:   source.timeline,
      settings:   source.settings,
      userId:     session.user.id,
    },
    include: { mediaFiles: true },
  })

  return NextResponse.json({
    project: {
      ...copy,
      timeline:   JSON.parse(copy.timeline),
      settings:   JSON.parse(copy.settings),
      createdAt:  copy.createdAt.toISOString(),
      updatedAt:  copy.updatedAt.toISOString(),
      mediaFiles: [],
    },
  }, { status: 201 })
}
