import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

async function getProject(id: string, userId: string) {
  return prisma.project.findFirst({
    where: { id, userId },
    include: { mediaFiles: true },
  })
}

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const userId = session.user.id
  const p = await getProject(params.id, userId)
  if (!p) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  return NextResponse.json({
    project: {
      ...p,
      timeline: JSON.parse(p.timeline),
      settings: JSON.parse(p.settings),
      createdAt: p.createdAt.toISOString(),
      updatedAt: p.updatedAt.toISOString(),
      mediaFiles: p.mediaFiles.map(m => ({ ...m, createdAt: m.createdAt.toISOString() })),
    },
  })
}

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const userId = session.user.id
  const existing = await getProject(params.id, userId)
  if (!existing) return NextResponse.json({ error: 'Not found' }, { status: 404 })

  const body = await req.json()
  const updated = await prisma.project.update({
    where: { id: params.id },
    data: {
      name:       body.name       ?? existing.name,
      description:body.description ?? existing.description,
      thumbnail:  body.thumbnail  ?? existing.thumbnail,
      duration:   body.duration   ?? existing.duration,
      resolution: body.resolution ?? existing.resolution,
      fps:        body.fps        ?? existing.fps,
      status:     body.status     ?? existing.status,
      timeline:   body.timeline   ? JSON.stringify(body.timeline) : existing.timeline,
      settings:   body.settings   ? JSON.stringify(body.settings) : existing.settings,
    },
    include: { mediaFiles: true },
  })
  return NextResponse.json({
    project: {
      ...updated,
      timeline: JSON.parse(updated.timeline),
      settings: JSON.parse(updated.settings),
      createdAt: updated.createdAt.toISOString(),
      updatedAt: updated.updatedAt.toISOString(),
      mediaFiles: updated.mediaFiles.map(m => ({ ...m, createdAt: m.createdAt.toISOString() })),
    },
  })
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const userId = session.user.id
  const existing = await getProject(params.id, userId)
  if (!existing) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  await prisma.project.delete({ where: { id: params.id } })
  return NextResponse.json({ success: true })
}
