import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { v4 as uuid } from 'uuid'

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const userId = session.user.id
  const projects = await prisma.project.findMany({
    where: { userId },
    include: { mediaFiles: { select: { id: true, name: true, type: true, url: true, thumbnail: true, duration: true, size: true, width: true, height: true, createdAt: true, projectId: true } } },
    orderBy: { updatedAt: 'desc' },
  })
  const parsed = projects.map(p => ({
    ...p,
    timeline: JSON.parse(p.timeline),
    settings: JSON.parse(p.settings),
    createdAt: p.createdAt.toISOString(),
    updatedAt: p.updatedAt.toISOString(),
    mediaFiles: p.mediaFiles.map(m => ({ ...m, createdAt: m.createdAt.toISOString() })),
  }))
  return NextResponse.json({ projects: parsed })
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const userId = session.user.id
  const { name, resolution = '1080p', fps = 30 } = await req.json()
  if (!name) return NextResponse.json({ error: 'Name required' }, { status: 400 })

  const defaultTimeline = {
    tracks: [
      { id: uuid(), type: 'video',  name: 'Video 1',  muted: false, solo: false, clips: [], volume: 1, color: '#6c5ce7' },
      { id: uuid(), type: 'video',  name: 'Video 2',  muted: false, solo: false, clips: [], volume: 1, color: '#a29bfe' },
      { id: uuid(), type: 'audio',  name: 'Audio 1',  muted: false, solo: false, clips: [], volume: 1, color: '#00b894' },
      { id: uuid(), type: 'text',   name: 'Captions', muted: false, solo: false, clips: [], volume: 1, color: '#fdcb6e' },
      { id: uuid(), type: 'effect', name: 'Effects',  muted: false, solo: false, clips: [], volume: 1, color: '#e17055' },
    ],
    duration: 120,
    fps,
  }

  const project = await prisma.project.create({
    data: { name, userId, resolution, fps, timeline: JSON.stringify(defaultTimeline), settings: '{}' },
    include: { mediaFiles: true },
  })
  return NextResponse.json({
    project: {
      ...project,
      timeline: JSON.parse(project.timeline),
      settings: JSON.parse(project.settings),
      createdAt: project.createdAt.toISOString(),
      updatedAt: project.updatedAt.toISOString(),
      mediaFiles: [],
    },
  }, { status: 201 })
}
