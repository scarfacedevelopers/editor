import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { writeFile, mkdir } from 'fs/promises'
import { join } from 'path'
import { existsSync } from 'fs'

const UPLOAD_DIR = join(process.cwd(), 'public', 'uploads')

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const formData = await req.formData()
  const file      = formData.get('file') as File | null
  const projectId = formData.get('projectId') as string | null

  if (!file || !projectId)
    return NextResponse.json({ error: 'file and projectId required' }, { status: 400 })

  const userId = session.user.id
  const project = await prisma.project.findFirst({ where: { id: projectId, userId } })
  if (!project) return NextResponse.json({ error: 'Project not found' }, { status: 404 })

  // Ensure upload directory exists
  const dir = join(UPLOAD_DIR, projectId)
  if (!existsSync(dir)) await mkdir(dir, { recursive: true })

  const bytes  = await file.arrayBuffer()
  const buffer = Buffer.from(bytes)
  const ext    = file.name.split('.').pop() ?? 'bin'
  const safeName = `${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`
  const filePath = join(dir, safeName)
  await writeFile(filePath, buffer)

  const url = `/uploads/${projectId}/${safeName}`
  const type = file.type.startsWith('video/')  ? 'video'
             : file.type.startsWith('audio/')  ? 'audio'
             : file.type.startsWith('image/')  ? 'image'
             : 'video'

  const media = await prisma.mediaFile.create({
    data: {
      name:      file.name,
      type,
      url,
      size:      file.size,
      projectId,
    },
  })

  return NextResponse.json({
    media: { ...media, createdAt: media.createdAt.toISOString() },
  }, { status: 201 })
}

// Delete a media file
export async function DELETE(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const { mediaId } = await req.json()
  const media = await prisma.mediaFile.findUnique({ where: { id: mediaId }, include: { project: true } })
  if (!media || media.project.userId !== session.user.id)
    return NextResponse.json({ error: 'Not found' }, { status: 404 })
  await prisma.mediaFile.delete({ where: { id: mediaId } })
  return NextResponse.json({ success: true })
}
