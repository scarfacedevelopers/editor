export default function Loading() {
  return (
    <div className="min-h-screen bg-scarface-bg">
      <div className="border-b border-scarface-border bg-scarface-surface h-14" />
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <div className="h-8 w-48 shimmer rounded-lg mb-2" />
            <div className="h-4 w-24 shimmer rounded" />
          </div>
          <div className="h-10 w-32 shimmer rounded-xl" />
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {[...Array(8)].map((_, i) => (
            <div key={i} className="bg-scarface-card border border-scarface-border rounded-2xl overflow-hidden">
              <div className="aspect-video shimmer" />
              <div className="p-4 space-y-2">
                <div className="h-4 w-3/4 shimmer rounded" />
                <div className="h-3 w-1/2 shimmer rounded" />
                <div className="h-8 shimmer rounded-lg mt-3" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
