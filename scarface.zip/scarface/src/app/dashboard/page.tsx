'use client'
import { useEffect, useState, useCallback } from 'react'
import { useSession, signOut } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import toast from 'react-hot-toast'
import { Project } from '@/types'
import { formatDistanceToNow } from 'date-fns'
import LoadingSpinner from '@/components/ui/LoadingSpinner'
import Modal from '@/components/ui/Modal'

const STATUS_BADGE: Record<string, string> = {
  draft:     'bg-amber-950/60 text-amber-400 border border-amber-900/50',
  rendering: 'bg-blue-950/60 text-blue-400 border border-blue-900/50',
  exported:  'bg-emerald-950/60 text-emerald-400 border border-emerald-900/50',
  archived:  'bg-scarface-hover text-scarface-muted border border-scarface-border',
}

type SortKey = 'updatedAt' | 'createdAt' | 'name'

export default function DashboardPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [projects, setProjects] = useState<Project[]>([])
  const [loading, setLoading]   = useState(true)
  const [showNew, setShowNew]   = useState(false)
  const [newName, setNewName]   = useState('')
  const [newRes, setNewRes]     = useState<'720p'|'1080p'|'4K'>('1080p')
  const [creating, setCreating] = useState(false)
  const [deleting, setDeleting] = useState<string|null>(null)
  const [search, setSearch]     = useState('')
  const [sort, setSort]         = useState<SortKey>('updatedAt')

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/login')
  }, [status, router])

  const fetchProjects = useCallback(async () => {
    setLoading(true)
    try {
      const res  = await fetch('/api/projects')
      const data = await res.json()
      setProjects(data.projects ?? [])
    } catch {
      toast.error('Failed to load projects')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    if (status === 'authenticated') fetchProjects()
  }, [status, fetchProjects])

  async function createProject() {
    if (!newName.trim()) { toast.error('Enter a project name'); return }
    setCreating(true)
    const res  = await fetch('/api/projects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: newName.trim(), resolution: newRes }),
    })
    const data = await res.json()
    setCreating(false)
    if (!res.ok) { toast.error(data.error); return }
    toast.success('Project created!')
    router.push(`/editor/${data.project.id}`)
  }

  async function deleteProject(id: string, name: string) {
    if (!confirm(`Delete "${name}"? This cannot be undone.`)) return
    setDeleting(id)
    const res = await fetch(`/api/projects/${id}`, { method: 'DELETE' })
    if (res.ok) {
      setProjects(p => p.filter(x => x.id !== id))
      toast.success('Project deleted')
    } else {
      toast.error('Delete failed')
    }
    setDeleting(null)
  }

  async function duplicateProject(id: string) {
    const res  = await fetch(`/api/projects/${id}/duplicate`, { method: 'POST' })
    const data = await res.json()
    if (res.ok) {
      setProjects(p => [data.project, ...p])
      toast.success('Project duplicated')
    }
  }

  const filtered = projects
    .filter(p => p.name.toLowerCase().includes(search.toLowerCase()))
    .sort((a, b) => {
      if (sort === 'name') return a.name.localeCompare(b.name)
      return new Date(b[sort]).getTime() - new Date(a[sort]).getTime()
    })

  if (status === 'loading') return (
    <div className="min-h-screen bg-scarface-bg flex items-center justify-center">
      <LoadingSpinner size={32} className="text-scarface-accent" />
    </div>
  )

  return (
    <div className="min-h-screen bg-scarface-bg">
      {/* Topbar */}
      <header className="border-b border-scarface-border bg-scarface-surface sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-6 py-3 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-8 h-8 bg-scarface-accent rounded-lg flex items-center justify-center text-white font-display font-bold text-sm">S</div>
            <span className="font-display font-bold text-xl tracking-tight hidden sm:block">SCARFACE</span>
          </Link>
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-scarface-accent/20 border border-scarface-accent/40 flex items-center justify-center text-scarface-accent text-xs font-bold">
              {session?.user?.name?.charAt(0)?.toUpperCase() ?? 'U'}
            </div>
            <span className="text-scarface-muted text-sm hidden sm:block">{session?.user?.name}</span>
            <button
              onClick={() => signOut({ callbackUrl: '/' })}
              className="btn-ghost text-sm px-3 py-1.5"
            >
              Sign out
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Page header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="font-display font-bold text-3xl text-scarface-text mb-1">My Projects</h1>
            <p className="text-scarface-muted text-sm">
              {loading ? 'Loading…' : `${projects.length} project${projects.length !== 1 ? 's' : ''}`}
            </p>
          </div>
          <button
            onClick={() => setShowNew(true)}
            className="btn-primary px-6 py-2.5 rounded-xl font-semibold text-sm self-start sm:self-auto"
          >
            + New Project
          </button>
        </div>

        {/* Filters bar */}
        <div className="flex flex-col sm:flex-row gap-3 mb-6">
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search projects…"
            className="input-base max-w-xs"
          />
          <div className="flex items-center gap-2">
            <span className="text-xs text-scarface-muted">Sort:</span>
            {(['updatedAt','createdAt','name'] as SortKey[]).map(k => (
              <button key={k} onClick={() => setSort(k)}
                className={`text-xs px-3 py-1.5 rounded-lg border transition-all ${sort === k ? 'bg-scarface-accent border-scarface-accent text-white' : 'border-scarface-border text-scarface-muted hover:border-scarface-accent/50'}`}>
                {k === 'updatedAt' ? 'Recent' : k === 'createdAt' ? 'Created' : 'Name'}
              </button>
            ))}
          </div>
        </div>

        {/* Projects grid */}
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="bg-scarface-card border border-scarface-border rounded-2xl overflow-hidden">
                <div className="aspect-video shimmer" />
                <div className="p-4 space-y-2">
                  <div className="h-4 w-3/4 shimmer rounded" />
                  <div className="h-3 w-1/2 shimmer rounded" />
                </div>
              </div>
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-24 border border-dashed border-scarface-border rounded-2xl">
            <div className="text-5xl mb-4">🎬</div>
            <h3 className="font-display font-semibold text-xl text-scarface-text mb-2">
              {search ? 'No results found' : 'No projects yet'}
            </h3>
            <p className="text-scarface-muted mb-6 text-sm">
              {search ? `No projects match "${search}"` : 'Create your first project to start editing'}
            </p>
            {!search && (
              <button onClick={() => setShowNew(true)} className="btn-primary px-6 py-2.5 rounded-xl">
                Create your first project
              </button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {filtered.map(project => (
              <ProjectCard
                key={project.id}
                project={project}
                deleting={deleting === project.id}
                onDelete={() => deleteProject(project.id, project.name)}
                onDuplicate={() => duplicateProject(project.id)}
              />
            ))}
            {/* New project card */}
            <button
              onClick={() => setShowNew(true)}
              className="border border-dashed border-scarface-border rounded-2xl aspect-[4/3] flex flex-col items-center justify-center gap-3 text-scarface-dim hover:border-scarface-accent hover:text-scarface-accent transition-all group"
            >
              <span className="text-4xl font-light group-hover:scale-110 transition-transform">+</span>
              <span className="text-sm font-medium">New Project</span>
            </button>
          </div>
        )}
      </div>

      {/* New project modal */}
      <Modal open={showNew} onClose={() => setShowNew(false)} title="New Project">
        <div className="space-y-5">
          <div>
            <label className="label-sm">Project Name</label>
            <input
              autoFocus type="text" value={newName}
              onChange={e => setNewName(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && createProject()}
              placeholder="My awesome video"
              className="input-base"
            />
          </div>
          <div>
            <label className="label-sm">Resolution</label>
            <div className="flex gap-2">
              {(['720p','1080p','4K'] as const).map(r => (
                <button key={r} onClick={() => setNewRes(r)}
                  className={`flex-1 py-2 rounded-lg border text-sm font-medium transition-all ${newRes === r ? 'bg-scarface-accent border-scarface-accent text-white' : 'border-scarface-border text-scarface-muted hover:border-scarface-accent/50'}`}>
                  {r}
                </button>
              ))}
            </div>
          </div>
          <div className="flex gap-3 pt-2">
            <button onClick={() => setShowNew(false)} className="btn-ghost flex-1 py-3 rounded-xl">
              Cancel
            </button>
            <button onClick={createProject} disabled={creating || !newName.trim()}
              className="btn-primary flex-1 py-3 rounded-xl font-semibold disabled:opacity-50 flex items-center justify-center gap-2">
              {creating ? <><LoadingSpinner size={16} />Creating…</> : 'Create & Open →'}
            </button>
          </div>
        </div>
      </Modal>
    </div>
  )
}

function ProjectCard({ project, deleting, onDelete, onDuplicate }: {
  project: Project
  deleting: boolean
  onDelete: () => void
  onDuplicate: () => void
}) {
  const [menuOpen, setMenuOpen] = useState(false)

  return (
    <div className="bg-scarface-card border border-scarface-border rounded-2xl overflow-hidden hover:border-scarface-accent/30 transition-all group relative">
      {/* Thumbnail */}
      <Link href={`/editor/${project.id}`}>
        <div className="aspect-video bg-scarface-surface flex items-center justify-center border-b border-scarface-border relative overflow-hidden">
          {project.thumbnail
            ? <img src={project.thumbnail} alt={project.name} className="w-full h-full object-cover" />
            : (
              <div className="flex flex-col items-center gap-2 text-scarface-dim">
                <span className="text-4xl opacity-30">🎬</span>
                <span className="text-xs opacity-50">{project.resolution}</span>
              </div>
            )
          }
          {/* Play overlay */}
          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-all flex items-center justify-center">
            <div className="w-12 h-12 rounded-full border border-white/0 group-hover:border-white/30 bg-white/0 group-hover:bg-white/10 flex items-center justify-center transition-all">
              <span className="text-white/0 group-hover:text-white/90 text-lg pl-1 transition-all">▶</span>
            </div>
          </div>
        </div>
      </Link>

      {/* Info */}
      <div className="p-4">
        <div className="flex items-start justify-between gap-2 mb-3">
          <Link href={`/editor/${project.id}`} className="flex-1 min-w-0">
            <h3 className="font-display font-semibold text-scarface-text hover:text-scarface-accent transition-colors truncate text-sm">
              {project.name}
            </h3>
          </Link>
          <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium shrink-0 ${STATUS_BADGE[project.status] ?? STATUS_BADGE.draft}`}>
            {project.status}
          </span>
        </div>

        <div className="flex items-center justify-between text-xs text-scarface-dim mb-3">
          <span title={new Date(project.updatedAt).toLocaleString()}>
            {formatDistanceToNow(new Date(project.updatedAt), { addSuffix: true })}
          </span>
          <span>{project.resolution} · {project.fps}fps</span>
        </div>

        <div className="flex gap-2">
          <Link href={`/editor/${project.id}`}
            className="btn-surface text-xs px-3 py-1.5 flex-1 text-center rounded-lg">
            Open Editor
          </Link>

          {/* Context menu */}
          <div className="relative">
            <button onClick={() => setMenuOpen(v => !v)}
              className="btn-ghost text-xs px-2.5 py-1.5 rounded-lg">
              ···
            </button>
            {menuOpen && (
              <>
                <div className="fixed inset-0 z-10" onClick={() => setMenuOpen(false)} />
                <div className="absolute bottom-full right-0 mb-1 bg-scarface-card border border-scarface-border rounded-xl shadow-xl z-20 py-1 w-40 overflow-hidden">
                  <button onClick={() => { onDuplicate(); setMenuOpen(false) }}
                    className="w-full text-left px-4 py-2 text-xs text-scarface-muted hover:bg-scarface-hover hover:text-scarface-text transition-colors">
                    ⎘ Duplicate
                  </button>
                  <div className="h-px bg-scarface-border mx-2 my-1" />
                  <button onClick={() => { onDelete(); setMenuOpen(false) }} disabled={deleting}
                    className="w-full text-left px-4 py-2 text-xs text-red-400 hover:bg-red-900/20 transition-colors disabled:opacity-50">
                    {deleting ? '⏳ Deleting…' : '🗑 Delete'}
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
