import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { prisma } from '@/lib/prisma'
import EditorWorkspace from '@/components/editor/EditorWorkspace'

export default async function EditorPage({ params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)
  if (!session?.user) redirect('/login')

  const userId  = session.user.id
  const project = await prisma.project.findFirst({
    where: { id: params.id, userId },
    include: { mediaFiles: true },
  })
  if (!project) redirect('/dashboard')

  const serialized = {
    ...project,
    timeline:   JSON.parse(project.timeline),
    settings:   JSON.parse(project.settings),
    createdAt:  project.createdAt.toISOString(),
    updatedAt:  project.updatedAt.toISOString(),
    mediaFiles: project.mediaFiles.map(m => ({ ...m, createdAt: m.createdAt.toISOString() })),
  }

  return <EditorWorkspace initialProject={serialized} />
}
