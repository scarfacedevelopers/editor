'use client'
import { useEffect } from 'react'
import Link from 'next/link'

export default function Error({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => { console.error(error) }, [error])
  return (
    <div className="min-h-screen bg-scarface-bg flex items-center justify-center px-6 text-center">
      <div>
        <div className="text-5xl mb-6">⚠</div>
        <h1 className="font-display font-bold text-3xl text-scarface-text mb-3">Something went wrong</h1>
        <p className="text-scarface-muted mb-8 max-w-md">{error.message || 'An unexpected error occurred.'}</p>
        <div className="flex gap-3 justify-center">
          <button onClick={reset} className="btn-primary px-6 py-2.5 rounded-xl font-semibold">Try again</button>
          <Link href="/dashboard" className="btn-ghost px-6 py-2.5 rounded-xl">Dashboard</Link>
        </div>
      </div>
    </div>
  )
}
