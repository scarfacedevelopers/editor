import type { Metadata } from 'next'
import { Syne, Space_Mono, DM_Sans } from 'next/font/google'
import './globals.css'
import { Providers } from '@/components/layout/Providers'
import { Toaster } from 'react-hot-toast'

const syne = Syne({
  subsets: ['latin'],
  variable: '--font-display',
  weight: ['400','500','600','700','800'],
})
const dmSans = DM_Sans({
  subsets: ['latin'],
  variable: '--font-body',
  weight: ['300','400','500','600'],
})
const spaceMono = Space_Mono({
  subsets: ['latin'],
  variable: '--font-mono',
  weight: ['400','700'],
})

export const metadata: Metadata = {
  title: 'Scarface — Professional Video Editor',
  description: 'Professional browser-based video editing platform. Cut, trim, color grade, and export stunning videos online.',
  icons: { icon: '/favicon.ico' },
  openGraph: {
    title: 'Scarface Video Editor',
    description: 'Professional browser-based video editing',
    type: 'website',
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${syne.variable} ${dmSans.variable} ${spaceMono.variable}`}>
      <body className="bg-scarface-bg text-scarface-text font-body antialiased">
        <Providers>
          {children}
          <Toaster
            position="bottom-center"
            toastOptions={{
              style: {
                background: '#141720',
                color: '#e8eaf0',
                border: '1px solid #1e2333',
                fontFamily: 'var(--font-body)',
                fontSize: '13px',
              },
              success: { iconTheme: { primary: '#2ec4b6', secondary: '#141720' } },
              error:   { iconTheme: { primary: '#e63946', secondary: '#141720' } },
            }}
          />
        </Providers>
      </body>
    </html>
  )
}
