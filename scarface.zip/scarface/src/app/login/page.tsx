'use client'
import { useState } from 'react'
import { signIn } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import toast from 'react-hot-toast'

export default function LoginPage() {
  const router = useRouter()
  const [email, setEmail]       = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading]   = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    const res = await signIn('credentials', { email, password, redirect: false })
    setLoading(false)
    if (res?.error) {
      toast.error('Invalid email or password')
    } else {
      toast.success('Welcome back!')
      router.push('/dashboard')
      router.refresh()
    }
  }

  return (
    <div className="min-h-screen bg-scarface-bg flex items-center justify-center px-4">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-[500px] h-[500px] bg-scarface-accent/5 blur-[120px] rounded-full" />
      </div>
      <div className="w-full max-w-md relative">
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center gap-2 mb-6">
            <div className="w-10 h-10 bg-scarface-accent rounded-xl flex items-center justify-center text-white font-display font-bold">S</div>
            <span className="font-display font-bold text-2xl tracking-tight">SCARFACE</span>
          </Link>
          <h1 className="font-display font-bold text-3xl text-scarface-text mb-2">Welcome back</h1>
          <p className="text-scarface-muted text-sm">Sign in to continue editing</p>
        </div>
        <div className="bg-scarface-card border border-scarface-border rounded-2xl p-8">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="label-sm">Email</label>
              <input
                type="email" required value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="input-base"
              />
            </div>
            <div>
              <label className="label-sm">Password</label>
              <input
                type="password" required value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••••"
                className="input-base"
              />
            </div>
            <button
              type="submit" disabled={loading}
              className="btn-primary w-full py-3 rounded-xl text-base font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'Signing in...' : 'Sign in →'}
            </button>
          </form>
          <div className="mt-6 text-center">
            <p className="text-scarface-muted text-sm">
              Don&apos;t have an account?{' '}
              <Link href="/signup" className="text-scarface-accent hover:underline">Sign up free</Link>
            </p>
          </div>
          <div className="mt-4 pt-4 border-t border-scarface-border text-center">
            <p className="text-xs text-scarface-dim">Demo: demo@scarface.app / password123</p>
          </div>
        </div>
      </div>
    </div>
  )
}
