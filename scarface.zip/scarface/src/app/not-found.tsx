import Link from 'next/link'

export default function NotFound() {
  return (
    <div className="min-h-screen bg-scarface-bg flex items-center justify-center px-6 text-center">
      <div>
        <div className="font-display font-bold text-8xl text-scarface-accent/20 mb-4">404</div>
        <h1 className="font-display font-bold text-3xl text-scarface-text mb-3">Page not found</h1>
        <p className="text-scarface-muted mb-8">The page you&apos;re looking for doesn&apos;t exist.</p>
        <Link href="/" className="btn-primary px-8 py-3 rounded-xl font-semibold inline-block">
          Go home
        </Link>
      </div>
    </div>
  )
}
