import Link from 'next/link'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { redirect } from 'next/navigation'

export default async function HomePage() {
  const session = await getServerSession(authOptions)
  if (session) redirect('/dashboard')

  return (
    <main className="min-h-screen bg-scarface-bg overflow-x-hidden">
      {/* Nav */}
      <nav className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-8 py-4 border-b border-scarface-border/50 bg-scarface-bg/80 backdrop-blur-md">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-scarface-accent rounded-lg flex items-center justify-center text-white font-display font-bold text-sm">S</div>
          <span className="font-display font-bold text-xl tracking-tight text-scarface-text">SCARFACE</span>
        </div>
        <div className="flex items-center gap-3">
          <Link href="/login"  className="btn-ghost text-sm px-4 py-2">Sign in</Link>
          <Link href="/signup" className="btn-primary text-sm px-4 py-2">Get started free</Link>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative pt-36 pb-24 px-6 flex flex-col items-center text-center overflow-hidden">
        {/* Background glow */}
        <div className="absolute top-20 left-1/2 -translate-x-1/2 w-[700px] h-[400px] bg-scarface-accent/5 blur-[120px] rounded-full pointer-events-none" />
        <div className="absolute top-40 left-1/4 w-[300px] h-[300px] bg-purple-900/10 blur-[80px] rounded-full pointer-events-none" />

        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-scarface-accent/30 bg-scarface-accent/10 text-scarface-accent text-xs font-medium mb-8">
          <span className="w-1.5 h-1.5 rounded-full bg-scarface-accent animate-pulse" />
          Now with AI-powered editing tools
        </div>

        <h1 className="font-display font-bold text-5xl md:text-7xl leading-[1.05] tracking-tight max-w-4xl mb-6">
          <span className="text-scarface-text">Professional video editing</span>
          <br />
          <span className="text-scarface-accent">right in your browser</span>
        </h1>

        <p className="text-scarface-muted text-lg max-w-xl leading-relaxed mb-10">
          Cut, trim, color grade, add effects, and export cinematic videos — no software download required. Powered by WebGL for real-time previews.
        </p>

        <div className="flex flex-col sm:flex-row gap-3 mb-16">
          <Link href="/signup" className="btn-primary text-base px-8 py-3 rounded-xl font-semibold">
            Start editing free →
          </Link>
          <Link href="/login" className="btn-ghost text-base px-8 py-3 rounded-xl">
            Sign in to your projects
          </Link>
        </div>

        {/* Editor Preview Mockup */}
        <div className="relative w-full max-w-5xl mx-auto rounded-2xl overflow-hidden border border-scarface-border shadow-2xl shadow-black/60">
          <div className="bg-scarface-surface border-b border-scarface-border flex items-center gap-2 px-4 py-3">
            <div className="w-3 h-3 rounded-full bg-red-500/70" />
            <div className="w-3 h-3 rounded-full bg-yellow-500/70" />
            <div className="w-3 h-3 rounded-full bg-green-500/70" />
            <span className="ml-3 text-xs text-scarface-muted font-mono">scarface.app/editor</span>
          </div>
          <div className="bg-scarface-bg p-0 aspect-[16/8] flex">
            {/* Sidebar stub */}
            <div className="w-12 bg-scarface-surface border-r border-scarface-border flex flex-col items-center py-3 gap-3">
              {['🎬','T','✦','⇄','♪','◈'].map((icon, i) => (
                <div key={i} className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs ${i === 0 ? 'bg-scarface-accent/20 text-scarface-accent' : 'text-scarface-dim'}`}>{icon}</div>
              ))}
            </div>
            {/* Media panel stub */}
            <div className="w-44 bg-scarface-surface border-r border-scarface-border p-2">
              <div className="text-xs text-scarface-muted mb-2 px-1">MEDIA LIBRARY</div>
              <div className="grid grid-cols-2 gap-1">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="aspect-video bg-scarface-card rounded shimmer" />
                ))}
              </div>
            </div>
            {/* Preview */}
            <div className="flex-1 flex flex-col">
              <div className="flex-1 bg-black flex items-center justify-center">
                <div className="w-16 h-16 rounded-full bg-scarface-accent/20 border border-scarface-accent/40 flex items-center justify-center text-2xl">▶</div>
              </div>
              <div className="h-20 bg-scarface-surface border-t border-scarface-border p-2">
                <div className="flex gap-1 mb-1.5">
                  {[...Array(4)].map((_, i) => <div key={i} className={`h-5 rounded ${['w-24 bg-purple-800/60','w-16 bg-purple-700/40','w-28 bg-green-800/50','w-12 bg-yellow-800/40'][i]}`} />)}
                </div>
                <div className="flex gap-1">
                  {[...Array(3)].map((_, i) => <div key={i} className={`h-5 rounded ${['w-32 bg-green-800/50','w-20 bg-yellow-700/40','w-16 bg-red-800/40'][i]}`} />)}
                </div>
              </div>
            </div>
            {/* Props panel */}
            <div className="w-40 bg-scarface-surface border-l border-scarface-border p-2">
              <div className="text-xs text-scarface-muted mb-2">PROPERTIES</div>
              {['Scale','Opacity','Brightness','Contrast'].map((label) => (
                <div key={label} className="mb-3">
                  <div className="text-xs text-scarface-dim mb-1">{label}</div>
                  <div className="h-1 bg-scarface-border rounded">
                    <div className="h-1 bg-scarface-accent rounded" style={{ width: `${Math.random() * 50 + 40}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-24 px-6 max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="font-display font-bold text-4xl text-scarface-text mb-4">Everything you need to create</h2>
          <p className="text-scarface-muted text-lg max-w-xl mx-auto">Professional-grade tools that run entirely in your browser, no plugins or downloads needed.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[
            { icon: '🎬', title: 'Multi-track Timeline', desc: 'Layer video, audio, text, and effects on unlimited tracks with frame-accurate editing.' },
            { icon: '🤖', title: 'AI Auto-Subtitles',   desc: 'Generate accurate subtitles in 40+ languages using built-in speech recognition.' },
            { icon: '🌿', title: 'Chroma Key',          desc: 'Remove green screen backgrounds and composite subjects into any scene.' },
            { icon: '🎨', title: 'Color Grading',       desc: 'Professional LUT presets and manual HSL color wheels for cinematic looks.' },
            { icon: '⚡', title: 'GPU Acceleration',    desc: 'WebGL-powered real-time preview and blazing fast export with hardware acceleration.' },
            { icon: '☁',  title: 'Cloud Projects',     desc: 'Auto-save to the cloud. Pick up where you left off from any device.' },
            { icon: '🔇', title: 'Noise Reduction',     desc: 'AI-powered audio cleanup removes background hiss from your recordings.' },
            { icon: '✦',  title: '100+ Effects',        desc: 'Blur, glitch, VHS, film grain, light leaks, and animated motion presets.' },
            { icon: '📤', title: 'Flexible Export',     desc: 'Export in 720p, 1080p, or 4K in MP4, MOV, WebM or animated GIF.' },
          ].map(({ icon, title, desc }) => (
            <div key={title} className="bg-scarface-card border border-scarface-border rounded-2xl p-6 hover:border-scarface-accent/40 transition-colors group">
              <div className="text-3xl mb-4">{icon}</div>
              <h3 className="font-display font-semibold text-lg text-scarface-text mb-2 group-hover:text-scarface-accent transition-colors">{title}</h3>
              <p className="text-scarface-muted text-sm leading-relaxed">{desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 px-6 text-center">
        <div className="max-w-2xl mx-auto bg-scarface-card border border-scarface-border rounded-3xl p-12">
          <h2 className="font-display font-bold text-4xl text-scarface-text mb-4">Ready to start editing?</h2>
          <p className="text-scarface-muted mb-8">Join thousands of creators making videos with Scarface.</p>
          <Link href="/signup" className="btn-primary text-base px-10 py-3 rounded-xl inline-block font-semibold">
            Create your free account →
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-scarface-border px-8 py-8 flex items-center justify-between text-scarface-dim text-sm">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 bg-scarface-accent rounded flex items-center justify-center text-white text-xs font-bold">S</div>
          <span className="font-display font-bold tracking-tight">SCARFACE</span>
        </div>
        <div>© {new Date().getFullYear()} Scarface. All rights reserved.</div>
      </footer>
    </main>
  )
}
