'use client'
import { useState } from 'react'
import { signIn } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import toast from 'react-hot-toast'

export default function SignupPage() {
  const router = useRouter()
  const [name, setName]         = useState('')
  const [email, setEmail]       = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading]   = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (password.length < 6) { toast.error('Password must be at least 6 characters'); return }
    setLoading(true)
    const res = await fetch('/api/auth/signup', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, password }),
    })
    if (!res.ok) {
      const data = await res.json()
      toast.error(data.error ?? 'Signup failed')
      setLoading(false)
      return
    }
    const loginRes = await signIn('credentials', { email, password, redirect: false })
    setLoading(false)
    if (loginRes?.error) { toast.error('Auto-login failed, please sign in'); router.push('/login') }
    else { toast.success('Account created!'); router.push('/dashboard'); router.refresh() }
  }

  return (
    <div className="min-h-screen bg-scarface-bg flex items-center justify-center px-4">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-[500px] h-[500px] bg-scarface-accent/5 blur-[120px] rounded-full" />
      </div>
      <div className="w-full max-w-md relative">
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center gap-2 mb-6">
            <div className="w-10 h-10 bg-scarface-accent rounded-xl flex items-center justify-center text-white font-display font-bold">S</div>
            <span className="font-display font-bold text-2xl tracking-tight">SCARFACE</span>
          </Link>
          <h1 className="font-display font-bold text-3xl text-scarface-text mb-2">Create your account</h1>
          <p className="text-scarface-muted text-sm">Start editing videos for free</p>
        </div>
        <div className="bg-scarface-card border border-scarface-border rounded-2xl p-8">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="label-sm">Full name</label>
              <input type="text" required value={name} onChange={e => setName(e.target.value)} placeholder="Your name" className="input-base" />
            </div>
            <div>
              <label className="label-sm">Email</label>
              <input type="email" required value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" className="input-base" />
            </div>
            <div>
              <label className="label-sm">Password</label>
              <input type="password" required value={password} onChange={e => setPassword(e.target.value)} placeholder="Min. 6 characters" className="input-base" />
            </div>
            <button type="submit" disabled={loading} className="btn-primary w-full py-3 rounded-xl text-base font-semibold disabled:opacity-50">
              {loading ? 'Creating account...' : 'Create account →'}
            </button>
          </form>
          <div className="mt-6 text-center">
            <p className="text-scarface-muted text-sm">
              Already have an account?{' '}
              <Link href="/login" className="text-scarface-accent hover:underline">Sign in</Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
