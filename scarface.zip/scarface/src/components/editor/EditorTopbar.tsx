'use client'
import { useState } from 'react'
import Link from 'next/link'
import { useEditorStore } from '@/store/editor'
import { Project } from '@/types'
import toast from 'react-hot-toast'

type SaveStatus = 'saved' | 'saving' | 'unsaved' | 'error'

interface Props {
  project:    Project
  saveStatus: SaveStatus
  onSave:     () => Promise<boolean>
}

const RESOLUTIONS = ['720p', '1080p', '4K'] as const
const FORMATS     = ['mp4', 'mov', 'webm', 'gif'] as const
const STATUS_LABELS: Record<SaveStatus, string> = {
  saved:   '● Saved',
  saving:  '◌ Saving…',
  unsaved: '○ Unsaved',
  error:   '⚠ Save error',
}
const STATUS_COLORS: Record<SaveStatus, string> = {
  saved:   'text-emerald-500',
  saving:  'text-scarface-muted animate-pulse',
  unsaved: 'text-amber-400',
  error:   'text-red-400',
}

export default function EditorTopbar({ project, saveStatus, onSave }: Props) {
  const { undo, redo, exportSettings, setExportSettings, timeline, tool, setTool } = useEditorStore()
  const [showExport, setShowExport] = useState(false)
  const [exporting, setExporting]   = useState(false)

  async function startExport() {
    setExporting(true)
    const res = await fetch('/api/export', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ projectId: project.id, ...exportSettings }),
    })
    setExporting(false)
    if (res.ok) {
      toast.success('Export started! Your video will be ready shortly.')
      setShowExport(false)
    } else {
      toast.error('Export failed')
    }
  }

  const TOOLS = [
    { id: 'select', icon: '↖', tip: 'Select (V)' },
    { id: 'cut',    icon: '✂', tip: 'Cut (C)'    },
    { id: 'text',   icon: 'T', tip: 'Text (T)'   },
    { id: 'zoom',   icon: '⊕', tip: 'Zoom (Z)'   },
  ] as const

  return (
    <>
      <header className="h-12 bg-scarface-surface border-b border-scarface-border flex items-center justify-between px-4 shrink-0 z-20">
        {/* Left */}
        <div className="flex items-center gap-3 min-w-0">
          <Link href="/dashboard" className="flex items-center gap-2 shrink-0">
            <div className="w-7 h-7 bg-scarface-accent rounded-lg flex items-center justify-center text-white font-display font-bold text-xs">S</div>
            <span className="font-display font-bold text-sm tracking-tight hidden md:block">SCARFACE</span>
          </Link>
          <span className="text-scarface-dim text-xs hidden sm:block">›</span>
          <span className="text-scarface-text text-sm font-medium truncate max-w-[140px]">{project.name}</span>
          <span className={`text-[10px] hidden sm:block ${STATUS_COLORS[saveStatus]}`}>
            {STATUS_LABELS[saveStatus]}
          </span>
        </div>

        {/* Center – edit tools */}
        <div className="flex items-center gap-1 absolute left-1/2 -translate-x-1/2">
          <button onClick={undo} title="Undo (⌘Z)" className="btn-ghost px-2 py-1.5 text-xs">↩</button>
          <button onClick={redo} title="Redo (⌘⇧Z)" className="btn-ghost px-2 py-1.5 text-xs">↪</button>
          <div className="w-px h-5 bg-scarface-border mx-1" />
          {TOOLS.map(({ id, icon, tip }) => (
            <button key={id} title={tip} onClick={() => setTool(id as any)}
              className={`w-8 h-8 rounded-lg text-sm flex items-center justify-center transition-all font-display
                ${tool === id ? 'bg-scarface-accent/20 text-scarface-accent' : 'text-scarface-dim hover:bg-scarface-hover hover:text-scarface-muted'}`}>
              {icon}
            </button>
          ))}
        </div>

        {/* Right */}
        <div className="flex items-center gap-2 shrink-0">
          <span className="text-[10px] text-scarface-dim hidden lg:block">{project.resolution} · {project.fps}fps</span>
          <button onClick={async () => { const ok = await onSave(); if (ok) toast.success('Saved!') }}
            className="btn-ghost text-xs px-3 py-1.5">Save</button>
          <Link href="/dashboard" className="btn-ghost text-xs px-3 py-1.5">← Back</Link>
          <button onClick={() => setShowExport(true)} className="btn-primary text-xs px-4 py-1.5 rounded-lg font-semibold">
            Export ↗
          </button>
        </div>
      </header>

      {/* Export Modal */}
      {showExport && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-[100] flex items-center justify-center px-4"
             onClick={e => { if (e.target === e.currentTarget) setShowExport(false) }}>
          <div className="bg-scarface-card border border-scarface-border rounded-2xl p-8 w-full max-w-md shadow-2xl">
            <h2 className="font-display font-bold text-2xl mb-6 text-scarface-text">Export Video</h2>
            <div className="space-y-5">
              <div>
                <label className="label-sm">Resolution</label>
                <div className="flex gap-2">
                  {RESOLUTIONS.map(r => (
                    <button key={r} onClick={() => setExportSettings({ resolution: r })}
                      className={`flex-1 py-2 rounded-lg border text-sm font-medium transition-all ${exportSettings.resolution === r ? 'bg-scarface-accent border-scarface-accent text-white' : 'border-scarface-border text-scarface-muted hover:border-scarface-accent/50'}`}>
                      {r}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="label-sm">Format</label>
                <div className="flex gap-2">
                  {FORMATS.map(f => (
                    <button key={f} onClick={() => setExportSettings({ format: f })}
                      className={`flex-1 py-2 rounded-lg border text-sm font-medium transition-all ${exportSettings.format === f ? 'bg-scarface-accent border-scarface-accent text-white' : 'border-scarface-border text-scarface-muted hover:border-scarface-accent/50'}`}>
                      {f.toUpperCase()}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="label-sm">Quality — {exportSettings.quality}%</label>
                <input type="range" min={10} max={100} value={exportSettings.quality}
                  onChange={e => setExportSettings({ quality: Number(e.target.value) })} className="w-full" />
              </div>
              <div>
                <label className="label-sm">Frame Rate</label>
                <div className="flex gap-2">
                  {[24, 30, 60].map(fps => (
                    <button key={fps} onClick={() => setExportSettings({ fps })}
                      className={`flex-1 py-2 rounded-lg border text-sm font-medium transition-all ${exportSettings.fps === fps ? 'bg-scarface-accent border-scarface-accent text-white' : 'border-scarface-border text-scarface-muted hover:border-scarface-accent/50'}`}>
                      {fps}fps
                    </button>
                  ))}
                </div>
              </div>
              <div className="bg-scarface-surface rounded-xl p-4 text-sm text-scarface-muted space-y-1">
                <div className="flex justify-between"><span>Duration</span><span className="text-scarface-text">{Math.floor(timeline.duration/60)}:{String(timeline.duration%60).padStart(2,'0')}</span></div>
                <div className="flex justify-between"><span>Codec</span><span className="text-scarface-text">H.264 / AAC</span></div>
                <div className="flex justify-between"><span>Est. size</span><span className="text-scarface-text">~{Math.round(timeline.duration * exportSettings.quality * 0.18)} MB</span></div>
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <button onClick={() => setShowExport(false)} className="btn-ghost flex-1 py-3 rounded-xl">Cancel</button>
              <button onClick={startExport} disabled={exporting}
                className="btn-primary flex-1 py-3 rounded-xl font-semibold disabled:opacity-50">
                {exporting ? '⏳ Starting…' : '⬇ Export Now'}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
