'use client'
import { useEffect } from 'react'
import { useEditorStore } from '@/store/editor'
import { Project } from '@/types'
import EditorTopbar    from './EditorTopbar'
import LeftToolbar     from './LeftToolbar'
import MediaPanel      from './MediaPanel'
import PreviewPlayer   from './PreviewPlayer'
import PropertiesPanel from './PropertiesPanel'
import Timeline        from './Timeline'
import { useAutoSave }           from '@/hooks/useAutoSave'
import { useKeyboardShortcuts }  from '@/hooks/useKeyboardShortcuts'
import toast from 'react-hot-toast'

interface Props { initialProject: Project }

export default function EditorWorkspace({ initialProject }: Props) {
  const { setProject, timeline } = useEditorStore()

  useEffect(() => { setProject(initialProject) }, [initialProject.id])

  const { status, saveNow } = useAutoSave(initialProject.id, timeline)

  useKeyboardShortcuts(async () => {
    const ok = await saveNow()
    if (ok) toast.success('Saved')
  })

  return (
    <div className="h-screen w-screen flex flex-col overflow-hidden bg-scarface-bg select-none">
      <EditorTopbar project={initialProject} saveStatus={status} onSave={saveNow} />
      <div className="flex flex-1 overflow-hidden">
        <LeftToolbar />
        <MediaPanel />
        <div className="flex flex-col flex-1 overflow-hidden">
          <PreviewPlayer />
        </div>
        <PropertiesPanel />
      </div>
      <Timeline projectId={initialProject.id} />
    </div>
  )
}
