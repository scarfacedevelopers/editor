'use client'
import { useEditorStore } from '@/store/editor'

const TOOLS = [
  { id: 'media',       icon: '🎬', label: 'Media'   },
  { id: 'text',        icon: 'T',  label: 'Text'    },
  { id: 'effects',     icon: '✦',  label: 'FX'      },
  { id: 'transitions', icon: '⇄',  label: 'Trans'   },
  { id: 'audio',       icon: '♪',  label: 'Audio'   },
  { id: 'filters',     icon: '◈',  label: 'Filter'  },
  { id: 'ai',          icon: '◉',  label: 'AI'      },
] as const

export default function LeftToolbar() {
  const { panel, setPanel } = useEditorStore()
  return (
    <div className="w-14 bg-scarface-surface border-r border-scarface-border flex flex-col items-center py-3 gap-1 shrink-0">
      {TOOLS.map(({ id, icon, label }) => (
        <button key={id} onClick={() => setPanel(id as any)} title={label}
          className={`w-10 h-10 rounded-xl flex flex-col items-center justify-center gap-0.5 transition-all text-base
            ${panel === id ? 'bg-scarface-accent/20 text-scarface-accent' : 'text-scarface-dim hover:bg-scarface-hover hover:text-scarface-muted'}`}>
          <span className={icon === 'T' ? 'font-display font-bold text-base' : 'text-base leading-none'}>{icon}</span>
          <span className="text-[9px] font-medium leading-none">{label}</span>
        </button>
      ))}
    </div>
  )
}
