'use client'
import { useRef, useState } from 'react'
import { useEditorStore } from '@/store/editor'
import { MediaFile } from '@/types'
import toast from 'react-hot-toast'

export default function MediaPanel() {
  const { panel } = useEditorStore()

  const panels: Record<string, React.ReactNode> = {
    media:       <MediaLibraryPanel />,
    text:        <TextPanel />,
    effects:     <EffectsPanel />,
    transitions: <TransitionsPanel />,
    audio:       <AudioPanel />,
    filters:     <FiltersPanel />,
    ai:          <AIPanel />,
  }

  return (
    <div className="w-56 bg-scarface-surface border-r border-scarface-border flex flex-col shrink-0 overflow-hidden">
      {panels[panel] ?? null}
    </div>
  )
}

// ─── Media Library ──────────────────────────────────────────────────────────

function MediaLibraryPanel() {
  const { project, timeline, addClip } = useEditorStore()
  const fileRef = useRef<HTMLInputElement>(null)
  const [uploading, setUploading] = useState(false)
  const [mediaFiles, setMediaFiles] = useState<MediaFile[]>(project?.mediaFiles ?? [])
  const [search, setSearch] = useState('')

  async function handleUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file || !project) return
    setUploading(true)
    const fd = new FormData()
    fd.append('file', file)
    fd.append('projectId', project.id)
    const res  = await fetch('/api/upload', { method: 'POST', body: fd })
    const data = await res.json()
    setUploading(false)
    if (res.ok) {
      setMediaFiles(prev => [...prev, data.media])
      toast.success('Media uploaded!')
    } else {
      toast.error(data.error ?? 'Upload failed')
    }
    e.target.value = ''
  }

  function addToTimeline(media: MediaFile) {
    const videoTrack = timeline.tracks.find(t => t.type === (media.type === 'audio' ? 'audio' : 'video'))
    if (!videoTrack) { toast.error('No compatible track found'); return }
    const lastEnd = videoTrack.clips.reduce((max, c) => Math.max(max, c.startTime + c.duration), 0)
    addClip(videoTrack.id, {
      mediaId:    media.id,
      trackId:    videoTrack.id,
      startTime:  lastEnd,
      duration:   media.duration ?? 5,
      trimStart:  0,
      trimEnd:    0,
      volume:     1,
      opacity:    1,
      speed:      1,
      filters:    [],
      effects:    [],
      transform:  { x: 0, y: 0, scaleX: 1, scaleY: 1, rotation: 0 },
      name:       media.name,
    })
    toast.success(`${media.name} added to timeline`)
  }

  const filtered = mediaFiles.filter(m => m.name.toLowerCase().includes(search.toLowerCase()))

  return (
    <div className="flex flex-col h-full">
      <div className="panel-section flex items-center justify-between">
        <span className="text-xs font-semibold text-scarface-muted uppercase tracking-wider">Media Library</span>
        <button onClick={() => fileRef.current?.click()} className="btn-primary text-xs px-2 py-1 rounded-lg">
          {uploading ? '...' : '+ Import'}
        </button>
        <input ref={fileRef} type="file" accept="video/*,audio/*,image/*" className="hidden" onChange={handleUpload} />
      </div>

      <div className="px-3 py-2">
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search media..." className="input-base text-xs py-1.5" />
      </div>

      <div
        className="mx-3 mb-2 border border-dashed border-scarface-border rounded-xl p-3 text-center cursor-pointer hover:border-scarface-accent/50 transition-colors"
        onClick={() => fileRef.current?.click()}
        onDragOver={e => e.preventDefault()}
        onDrop={async e => {
          e.preventDefault()
          const file = e.dataTransfer.files[0]
          if (!file || !project) return
          setUploading(true)
          const fd = new FormData()
          fd.append('file', file)
          fd.append('projectId', project.id)
          const res = await fetch('/api/upload', { method: 'POST', body: fd })
          const data = await res.json()
          setUploading(false)
          if (res.ok) { setMediaFiles(prev => [...prev, data.media]); toast.success('Uploaded!') }
        }}
      >
        <div className="text-scarface-dim text-xs">{uploading ? 'Uploading...' : 'Drop files here'}</div>
      </div>

      <div className="flex-1 overflow-y-auto px-3 pb-3 space-y-2">
        {filtered.length === 0 && (
          <div className="text-center py-8 text-scarface-dim text-xs">No media yet. Import files above.</div>
        )}
        {filtered.map(media => (
          <div key={media.id} className="group flex items-center gap-2 bg-scarface-card border border-scarface-border rounded-lg p-2 cursor-pointer hover:border-scarface-accent/40 transition-all"
               onClick={() => addToTimeline(media)}>
            <div className="w-14 h-9 bg-scarface-surface rounded flex items-center justify-center text-lg shrink-0 overflow-hidden">
              {media.thumbnail
                ? <img src={media.thumbnail} className="w-full h-full object-cover" alt="" />
                : media.type === 'video' ? '🎬' : media.type === 'audio' ? '♪' : '🖼'
              }
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-xs text-scarface-text truncate">{media.name}</div>
              <div className="text-[10px] text-scarface-dim">{media.type} · {(media.size / 1024 / 1024).toFixed(1)}MB</div>
            </div>
            <span className="text-[9px] text-scarface-accent opacity-0 group-hover:opacity-100 transition-opacity">+Add</span>
          </div>
        ))}
      </div>
    </div>
  )
}

// ─── Text Panel ──────────────────────────────────────────────────────────────

const TEXT_PRESETS = ['Title Slide','Lower Third','Social Caption','Animated Name','Outline Text','Neon Glow','Subtitle','Watermark']

function TextPanel() {
  const { timeline, addClip, currentTime } = useEditorStore()
  const [text, setText] = useState('')

  function addTextClip(preset: string, content = preset) {
    const textTrack = timeline.tracks.find(t => t.type === 'text')
    if (!textTrack) { toast.error('No text track'); return }
    addClip(textTrack.id, {
      trackId: textTrack.id, startTime: currentTime, duration: 3, trimStart: 0, trimEnd: 0,
      volume: 1, opacity: 1, speed: 1, filters: [], effects: [],
      transform: { x: 0, y: 0, scaleX: 1, scaleY: 1, rotation: 0 },
      name: content,
      text: { content, fontSize: 48, fontFamily: 'Syne', color: '#ffffff', bold: true, italic: false, align: 'center', preset },
    })
    toast.success(`"${content}" added`)
  }

  return (
    <div className="flex flex-col h-full">
      <div className="panel-section">
        <span className="text-xs font-semibold text-scarface-muted uppercase tracking-wider">Text & Titles</span>
      </div>
      <div className="flex-1 overflow-y-auto p-3 space-y-3">
        <div className="space-y-1.5">
          <span className="label-sm">Presets</span>
          {TEXT_PRESETS.map(p => (
            <button key={p} onClick={() => addTextClip(p)}
              className="w-full text-left px-3 py-2 bg-scarface-card border border-scarface-border rounded-lg text-xs text-scarface-muted hover:border-scarface-accent/50 hover:text-scarface-text transition-all">
              {p}
            </button>
          ))}
        </div>
        <div>
          <span className="label-sm">Custom Text</span>
          <input value={text} onChange={e => setText(e.target.value)} placeholder="Type your text..." className="input-base text-xs mb-2" />
          <button onClick={() => text && addTextClip('Custom', text)} disabled={!text}
            className="btn-primary w-full py-2 rounded-lg text-xs disabled:opacity-40">
            Add to Timeline
          </button>
        </div>
      </div>
    </div>
  )
}

// ─── Effects Panel ───────────────────────────────────────────────────────────

const EFFECTS = ['Blur','Glitch','VHS Distort','Film Grain','Light Leak','Zoom Punch','Screen Shake','Fade In','Fade Out','Ken Burns','Spin','Bounce']

function EffectsPanel() {
  const { selectedClipId, timeline, updateClip } = useEditorStore()

  function applyEffect(effect: string) {
    if (!selectedClipId) { toast('Select a clip first', { icon: '👆' }); return }
    for (const track of timeline.tracks) {
      const clip = track.clips.find(c => c.id === selectedClipId)
      if (clip) {
        updateClip(track.id, selectedClipId, { effects: [...clip.effects, effect] })
        toast.success(`${effect} applied`)
        return
      }
    }
  }

  return (
    <div className="flex flex-col h-full">
      <div className="panel-section"><span className="text-xs font-semibold text-scarface-muted uppercase tracking-wider">Visual Effects</span></div>
      <div className="flex-1 overflow-y-auto p-3 space-y-1.5">
        {EFFECTS.map(e => (
          <button key={e} onClick={() => applyEffect(e)}
            className="w-full flex items-center justify-between px-3 py-2 bg-scarface-card border border-scarface-border rounded-lg text-xs text-scarface-muted hover:border-scarface-accent/50 hover:text-scarface-text transition-all">
            <span>✦ {e}</span><span className="text-scarface-accent text-[10px]">Add</span>
          </button>
        ))}
      </div>
    </div>
  )
}

// ─── Transitions ─────────────────────────────────────────────────────────────

const TRANSITIONS = ['Cut','Fade','Dissolve','Wipe Left','Wipe Right','Slide','Push','Zoom In','Spin','Glitch','Flash','Cross Blur']

function TransitionsPanel() {
  return (
    <div className="flex flex-col h-full">
      <div className="panel-section"><span className="text-xs font-semibold text-scarface-muted uppercase tracking-wider">Transitions</span></div>
      <div className="flex-1 overflow-y-auto p-3">
        <div className="grid grid-cols-2 gap-2">
          {TRANSITIONS.map(t => (
            <button key={t} onClick={() => toast.success(`${t} transition added`)}
              className="aspect-video bg-scarface-card border border-scarface-border rounded-lg text-[10px] text-scarface-muted hover:border-scarface-accent/50 hover:text-scarface-accent transition-all flex items-center justify-center text-center p-1">
              {t}
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}

// ─── Audio Panel ─────────────────────────────────────────────────────────────

const MUSIC = ['Upbeat Pop','Cinematic Epic','Lo-fi Chill','Corporate Drive','Dramatic Tension','Electronic Pulse','Acoustic Warm','Jazz Smooth']

function AudioPanel() {
  return (
    <div className="flex flex-col h-full">
      <div className="panel-section"><span className="text-xs font-semibold text-scarface-muted uppercase tracking-wider">Audio</span></div>
      <div className="flex-1 overflow-y-auto p-3 space-y-3">
        <div className="space-y-1.5">
          <span className="label-sm">AI Audio Tools</span>
          {[['🔇','Noise Reduction'],['〜','Equalizer'],['♪','Beat Sync'],['🔊','Volume Normalize']].map(([icon, label]) => (
            <button key={String(label)} onClick={() => toast.success(`${label} applied`)}
              className="w-full flex items-center gap-2 px-3 py-2 bg-scarface-card border border-scarface-border rounded-lg text-xs text-scarface-muted hover:border-scarface-accent/50 transition-all">
              <span>{icon}</span><span>{label}</span>
            </button>
          ))}
        </div>
        <div className="space-y-1.5">
          <span className="label-sm">Music Library</span>
          {MUSIC.map(m => (
            <div key={m} className="flex items-center justify-between px-3 py-2 bg-scarface-card border border-scarface-border rounded-lg hover:border-scarface-accent/40 transition-all cursor-pointer"
                 onClick={() => toast.success(`${m} added`)}>
              <span className="text-xs text-scarface-muted">♪ {m}</span>
              <span className="text-[10px] text-scarface-accent">+ Add</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

// ─── Filters Panel ───────────────────────────────────────────────────────────

const FILTERS = ['None','Vintage','Cinematic','B&W','Warm','Cool','Fade','Vivid','Matte','Drama','Sunset','Arctic']

function FiltersPanel() {
  const [active, setActive] = useState('None')
  const { selectedClipId, timeline, updateClip } = useEditorStore()

  function applyFilter(f: string) {
    setActive(f)
    if (!selectedClipId) { toast('Select a clip first', { icon: '👆' }); return }
    for (const track of timeline.tracks) {
      const clip = track.clips.find(c => c.id === selectedClipId)
      if (clip) { updateClip(track.id, selectedClipId, { filters: [{ type: f, intensity: 0.8 }] }); toast.success(`${f} filter applied`); return }
    }
  }

  return (
    <div className="flex flex-col h-full">
      <div className="panel-section"><span className="text-xs font-semibold text-scarface-muted uppercase tracking-wider">Color Filters</span></div>
      <div className="flex-1 overflow-y-auto p-3">
        <div className="grid grid-cols-2 gap-2">
          {FILTERS.map(f => (
            <button key={f} onClick={() => applyFilter(f)}
              className={`aspect-video rounded-lg text-[10px] font-medium flex items-center justify-center border transition-all
                ${active === f ? 'border-scarface-accent text-scarface-accent bg-scarface-accent/10' : 'bg-scarface-card border-scarface-border text-scarface-muted hover:border-scarface-accent/50'}`}>
              {f}
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}

// ─── AI Panel ────────────────────────────────────────────────────────────────

const AI_TOOLS = [
  { icon: '◉', title: 'Auto Subtitles',    desc: 'Generate captions from speech' },
  { icon: '🌿', title: 'Background Remove', desc: 'AI-powered background removal' },
  { icon: '🎤', title: 'Voice Enhance',     desc: 'Boost & clean voice audio' },
  { icon: '✂',  title: 'Smart Trim',        desc: 'Auto-remove silent parts' },
  { icon: '🎨', title: 'Style Transfer',    desc: 'Apply artistic styles' },
  { icon: '📊', title: 'Scene Detect',      desc: 'Auto-split into scenes' },
]

function AIPanel() {
  const [loading, setLoading] = useState<string | null>(null)

  async function runTool(title: string) {
    setLoading(title)
    await new Promise(r => setTimeout(r, 1500))
    setLoading(null)
    toast.success(`${title} complete!`)
  }

  return (
    <div className="flex flex-col h-full">
      <div className="panel-section"><span className="text-xs font-semibold text-scarface-muted uppercase tracking-wider">AI Tools</span></div>
      <div className="flex-1 overflow-y-auto p-3 space-y-2">
        {AI_TOOLS.map(({ icon, title, desc }) => (
          <button key={title} onClick={() => runTool(title)} disabled={loading === title}
            className="w-full text-left bg-scarface-card border border-scarface-border rounded-xl p-3 hover:border-scarface-accent/50 transition-all disabled:opacity-60">
            <div className="flex items-center gap-2 mb-1">
              <span>{icon}</span>
              <span className="text-xs font-semibold text-scarface-text">{title}</span>
              {loading === title && <span className="text-[10px] text-scarface-accent animate-pulse ml-auto">Running...</span>}
            </div>
            <div className="text-[10px] text-scarface-dim">{desc}</div>
          </button>
        ))}
      </div>
    </div>
  )
}
