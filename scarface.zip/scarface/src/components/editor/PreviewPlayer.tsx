'use client'
import { useEffect, useRef, useCallback } from 'react'
import { useEditorStore } from '@/store/editor'
import { formatTime } from '@/lib/utils'

export default function PreviewPlayer() {
  const {
    timeline, currentTime, playing, volume, muted, playbackSpeed,
    setCurrentTime, setPlaying, setVolume, setMuted,
  } = useEditorStore()

  const rafRef   = useRef<number>()
  const lastRef  = useRef<number>()
  const barRef   = useRef<HTMLDivElement>(null)
  const duration = Math.max(timeline.duration || 120, 1)

  const tick = useCallback((ts: number) => {
    if (!lastRef.current) lastRef.current = ts
    const dt = (ts - lastRef.current) / 1000
    lastRef.current = ts
    setCurrentTime((prev: number) => {
      const next = prev + dt * playbackSpeed
      if (next >= duration) { setPlaying(false); return 0 }
      return next
    })
    rafRef.current = requestAnimationFrame(tick)
  }, [duration, playbackSpeed, setCurrentTime, setPlaying])

  useEffect(() => {
    if (playing) {
      lastRef.current = undefined
      rafRef.current  = requestAnimationFrame(tick)
    } else {
      if (rafRef.current) cancelAnimationFrame(rafRef.current)
      lastRef.current = undefined
    }
    return () => { if (rafRef.current) cancelAnimationFrame(rafRef.current) }
  }, [playing, tick])

  function seek(e: React.MouseEvent<HTMLDivElement>) {
    const rect = barRef.current!.getBoundingClientRect()
    const t    = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width)) * duration
    setCurrentTime(t)
  }

  const pct = Math.min(100, (currentTime / duration) * 100)

  // Active clips at current time
  const activeClips = timeline.tracks.flatMap(t =>
    t.muted ? [] : t.clips.filter(c => c.startTime <= currentTime && c.startTime + c.duration > currentTime)
  )
  const activeText  = activeClips.find(c => c.text)
  const activeVideo = activeClips.find(c => !c.text)

  return (
    <div className="flex-1 flex flex-col bg-[#050507] overflow-hidden">
      {/* Canvas */}
      <div className="flex-1 flex items-center justify-center relative overflow-hidden">
        {/* Subtle grid */}
        <div className="absolute inset-0 opacity-[0.03]"
          style={{ backgroundImage: 'linear-gradient(#fff 1px,transparent 1px),linear-gradient(90deg,#fff 1px,transparent 1px)', backgroundSize: '48px 48px' }} />

        <div className="relative" style={{ width: 'min(88%, 840px)', aspectRatio: '16/9' }}>
          <div className="w-full h-full bg-black rounded overflow-hidden border border-white/[0.04] relative flex items-center justify-center shadow-2xl shadow-black/80">

            {activeVideo ? (
              /* Real media: show URL if it's a hosted file */
              activeVideo.mediaId && activeVideo.name ? (
                <div className="w-full h-full bg-gradient-to-br from-scarface-surface to-scarface-bg flex flex-col items-center justify-center gap-3">
                  <span className="text-5xl opacity-20">🎬</span>
                  <span className="text-scarface-dim text-sm">{activeVideo.name}</span>
                  <span className="text-scarface-dim/40 text-xs">Preview renders on export</span>
                </div>
              ) : null
            ) : (
              <div className="flex flex-col items-center gap-4 text-scarface-dim">
                <div className="w-16 h-16 rounded-full border border-scarface-border flex items-center justify-center text-2xl opacity-40">▶</div>
                <div className="text-center">
                  <div className="text-sm mb-1">Add media to the timeline</div>
                  <div className="text-xs opacity-50">Drag from the media library</div>
                </div>
              </div>
            )}

            {/* Text/caption overlay */}
            {activeText?.text && (
              <div className="absolute bottom-[8%] left-0 right-0 flex justify-center px-6 pointer-events-none">
                <span
                  className="bg-black/80 text-white px-5 py-2 rounded-lg text-center max-w-[80%] leading-snug"
                  style={{
                    fontFamily:  activeText.text.fontFamily,
                    fontSize:    `clamp(12px, ${activeText.text.fontSize / 5}px, 24px)`,
                    fontWeight:  activeText.text.bold ? 700 : 400,
                    fontStyle:   activeText.text.italic ? 'italic' : 'normal',
                    color:       activeText.text.color,
                    textAlign:   activeText.text.align,
                  }}
                >
                  {activeText.text.content}
                </span>
              </div>
            )}

            {/* Safe area guides */}
            <div className="absolute inset-[5%] border border-white/[0.04] rounded pointer-events-none" />
          </div>
        </div>

        {/* Status badges */}
        <div className="absolute top-3 left-3 flex gap-2 pointer-events-none">
          <span className="flex items-center gap-1.5 text-[10px] bg-black/60 border border-white/10 px-2.5 py-1 rounded-full text-white/60 backdrop-blur-sm">
            <span className={`w-1.5 h-1.5 rounded-full ${playing ? 'bg-scarface-accent animate-pulse' : 'bg-white/30'}`} />
            {playing ? 'Playing' : 'Paused'}
          </span>
          {activeClips.length > 0 && (
            <span className="text-[10px] bg-black/60 border border-white/10 px-2.5 py-1 rounded-full text-white/60 backdrop-blur-sm">
              {activeClips.length} clip{activeClips.length !== 1 ? 's' : ''} active
            </span>
          )}
        </div>
        <div className="absolute top-3 right-3 pointer-events-none">
          <span className="text-[10px] bg-black/60 border border-white/10 px-2.5 py-1 rounded-full text-white/60 backdrop-blur-sm">
            {useEditorStore.getState().project?.resolution ?? '1080p'} · {timeline.fps}fps
          </span>
        </div>
      </div>

      {/* Controls */}
      <div className="h-12 bg-scarface-surface border-t border-scarface-border flex items-center gap-3 px-4 shrink-0">
        <button onClick={() => setCurrentTime(0)} title="Go to start" className="text-scarface-muted hover:text-scarface-text transition-colors text-sm w-6 text-center">⏮</button>

        <button
          onClick={() => setPlaying(!playing)}
          className="w-8 h-8 rounded-full bg-scarface-accent hover:bg-red-600 active:scale-95 transition-all flex items-center justify-center text-white text-sm shrink-0"
        >
          {playing ? '⏸' : '▶'}
        </button>

        <button onClick={() => setCurrentTime(duration)} title="Go to end" className="text-scarface-muted hover:text-scarface-text transition-colors text-sm w-6 text-center">⏭</button>

        <span className="font-mono text-[11px] text-scarface-muted w-[110px] shrink-0 tabular-nums">
          {formatTime(currentTime)} / {formatTime(duration)}
        </span>

        {/* Seek bar */}
        <div ref={barRef} onClick={seek} className="flex-1 h-1 bg-scarface-border rounded cursor-pointer relative group py-2 -my-2">
          <div className="absolute inset-y-[7px] left-0 right-0 rounded">
            <div className="h-full bg-scarface-accent/30 rounded" />
          </div>
          <div className="absolute inset-y-[7px] left-0 bg-scarface-accent rounded transition-none" style={{ width: `${pct}%` }} />
          <div className="absolute top-1/2 -translate-y-1/2 w-3 h-3 rounded-full bg-white shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"
               style={{ left: `${pct}%`, transform: 'translate(-50%,-50%)' }} />
        </div>

        {/* Volume */}
        <button onClick={() => setMuted(!muted)} className="text-scarface-muted hover:text-scarface-text transition-colors text-sm w-5 text-center shrink-0">
          {muted ? '🔇' : volume > 0.6 ? '🔊' : volume > 0 ? '🔉' : '🔈'}
        </button>
        <input type="range" min={0} max={1} step={0.02} value={muted ? 0 : volume}
          onChange={e => { setVolume(Number(e.target.value)); if (muted) setMuted(false) }}
          className="w-16 shrink-0" />

        {/* Speed */}
        <select
          value={playbackSpeed}
          onChange={e => useEditorStore.setState({ playbackSpeed: Number(e.target.value) })}
          className="bg-scarface-card border border-scarface-border rounded-lg text-[11px] text-scarface-muted px-2 py-1 outline-none shrink-0"
        >
          {[0.25, 0.5, 0.75, 1, 1.25, 1.5, 2, 4].map(s => (
            <option key={s} value={s}>{s}×</option>
          ))}
        </select>
      </div>
    </div>
  )
}
