'use client'
import { useEditorStore } from '@/store/editor'
import { Clip } from '@/types'

export default function PropertiesPanel() {
  const { selectedClipId, timeline, updateClip, removeClip, splitClip, currentTime } = useEditorStore()

  let selectedClip: Clip | null = null
  let selectedTrackId = ''
  for (const track of timeline.tracks) {
    const c = track.clips.find(c => c.id === selectedClipId)
    if (c) { selectedClip = c; selectedTrackId = track.id; break }
  }

  function update(field: keyof Clip, value: number | string) {
    if (!selectedClip) return
    updateClip(selectedTrackId, selectedClip.id, { [field]: value })
  }

  function updateTransform(field: string, value: number) {
    if (!selectedClip) return
    updateClip(selectedTrackId, selectedClip.id, { transform: { ...selectedClip.transform, [field]: value } })
  }

  return (
    <div className="w-56 bg-scarface-surface border-l border-scarface-border flex flex-col shrink-0 overflow-hidden">
      <div className="panel-section flex items-center justify-between">
        <span className="text-xs font-semibold text-scarface-muted uppercase tracking-wider">Properties</span>
        {selectedClip && (
          <span className="text-[10px] bg-scarface-accent/10 text-scarface-accent px-2 py-0.5 rounded-full">
            {selectedClip.name.slice(0, 12)}{selectedClip.name.length > 12 ? '…' : ''}
          </span>
        )}
      </div>

      {!selectedClip ? (
        <div className="flex-1 flex items-center justify-center text-center px-4">
          <div>
            <div className="text-3xl mb-3 opacity-30">↖</div>
            <p className="text-xs text-scarface-dim leading-relaxed">Click a clip on the timeline to edit its properties</p>
          </div>
        </div>
      ) : (
        <div className="flex-1 overflow-y-auto">
          {/* Transform */}
          <Section title="Transform">
            <SliderRow label="Scale X"    value={selectedClip.transform.scaleX * 100} min={10} max={300} unit="%"
              onChange={v => updateTransform('scaleX', v / 100)} />
            <SliderRow label="Scale Y"    value={selectedClip.transform.scaleY * 100} min={10} max={300} unit="%"
              onChange={v => updateTransform('scaleY', v / 100)} />
            <SliderRow label="Rotation"   value={selectedClip.transform.rotation} min={-180} max={180} unit="°"
              onChange={v => updateTransform('rotation', v)} />
            <SliderRow label="Pos X"      value={selectedClip.transform.x} min={-960} max={960} unit="px"
              onChange={v => updateTransform('x', v)} />
            <SliderRow label="Pos Y"      value={selectedClip.transform.y} min={-540} max={540} unit="px"
              onChange={v => updateTransform('y', v)} />
          </Section>

          {/* Clip */}
          <Section title="Clip">
            <SliderRow label="Opacity" value={selectedClip.opacity * 100} min={0} max={100} unit="%"
              onChange={v => update('opacity', v / 100)} />
            <SliderRow label="Volume"  value={selectedClip.volume * 100} min={0} max={200} unit="%"
              onChange={v => update('volume', v / 100)} />
            <div className="mt-2">
              <div className="label-sm">Speed</div>
              <div className="flex flex-wrap gap-1">
                {[0.25, 0.5, 1, 1.5, 2, 4].map(s => (
                  <button key={s} onClick={() => update('speed', s)}
                    className={`text-[10px] px-2 py-1 rounded border transition-colors ${selectedClip!.speed === s ? 'bg-scarface-accent border-scarface-accent text-white' : 'border-scarface-border text-scarface-muted hover:border-scarface-accent/50'}`}>
                    {s}×
                  </button>
                ))}
              </div>
            </div>
          </Section>

          {/* Color */}
          <Section title="Color">
            {(['brightness','contrast','saturation'] as const).map(prop => (
              <SliderRow key={prop} label={prop.charAt(0).toUpperCase() + prop.slice(1)}
                value={0} min={-100} max={100} unit="" onChange={() => {}} />
            ))}
          </Section>

          {/* Text (if text clip) */}
          {selectedClip.text && (
            <Section title="Text">
              <textarea value={selectedClip.text.content}
                onChange={e => updateClip(selectedTrackId, selectedClip!.id, { text: { ...selectedClip!.text!, content: e.target.value } })}
                className="input-base text-xs resize-none h-16 mb-2" />
              <SliderRow label="Font size" value={selectedClip.text.fontSize} min={12} max={200} unit="px"
                onChange={v => updateClip(selectedTrackId, selectedClip!.id, { text: { ...selectedClip!.text!, fontSize: v } })} />
              <div className="mt-2">
                <div className="label-sm">Alignment</div>
                <div className="flex gap-1">
                  {(['left','center','right'] as const).map(a => (
                    <button key={a} onClick={() => updateClip(selectedTrackId, selectedClip!.id, { text: { ...selectedClip!.text!, align: a } })}
                      className={`flex-1 py-1 rounded border text-[10px] transition-colors ${selectedClip!.text!.align === a ? 'bg-scarface-accent border-scarface-accent text-white' : 'border-scarface-border text-scarface-muted'}`}>
                      {a[0].toUpperCase()}
                    </button>
                  ))}
                </div>
              </div>
            </Section>
          )}

          {/* Actions */}
          <Section title="Actions">
            <button onClick={() => { splitClip(selectedTrackId, selectedClip!.id, currentTime) }}
              className="btn-ghost w-full text-xs py-2 mb-2">
              ✂ Split at playhead
            </button>
            <button onClick={() => { removeClip(selectedTrackId, selectedClip!.id) }}
              className="w-full text-xs py-2 rounded-lg border border-red-900/30 text-red-400 hover:bg-red-900/20 transition-colors">
              🗑 Delete clip
            </button>
          </Section>
        </div>
      )}
    </div>
  )
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="panel-section">
      <div className="label-sm">{title}</div>
      {children}
    </div>
  )
}

function SliderRow({ label, value, min, max, unit, onChange }: {
  label: string; value: number; min: number; max: number; unit: string; onChange: (v: number) => void
}) {
  return (
    <div className="mb-3">
      <div className="flex justify-between items-center mb-1">
        <span className="text-[11px] text-scarface-muted">{label}</span>
        <span className="text-[11px] text-scarface-text font-mono">{Math.round(value)}{unit}</span>
      </div>
      <input type="range" min={min} max={max} value={value} onChange={e => onChange(Number(e.target.value))} className="w-full" />
    </div>
  )
}
