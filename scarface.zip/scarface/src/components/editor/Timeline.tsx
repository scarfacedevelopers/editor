'use client'
import { useRef, useState, useCallback } from 'react'
import { useEditorStore } from '@/store/editor'
import { Clip, Track } from '@/types'
import toast from 'react-hot-toast'

const TRACK_H = 34
const TRACK_COLORS: Record<string, { bg: string; border: string; hover: string }> = {
  video:   { bg: 'bg-purple-900/50',  border: 'border-purple-700/40', hover: 'hover:border-purple-400/60' },
  audio:   { bg: 'bg-emerald-900/50', border: 'border-emerald-700/40',hover: 'hover:border-emerald-400/60' },
  text:    { bg: 'bg-amber-900/50',   border: 'border-amber-700/40',  hover: 'hover:border-amber-400/60'  },
  effect:  { bg: 'bg-red-900/50',     border: 'border-red-700/40',    hover: 'hover:border-red-400/60'    },
  overlay: { bg: 'bg-sky-900/50',     border: 'border-sky-700/40',    hover: 'hover:border-sky-400/60'    },
}
const TRACK_ICONS: Record<string, string> = { video:'🎬', audio:'♪', text:'T', effect:'✦', overlay:'⊕' }

interface DragState { clipId: string; trackId: string; offsetSec: number }

export default function Timeline({ projectId }: { projectId: string }) {
  const {
    timeline, zoom, setZoom, currentTime, setCurrentTime,
    selectClip, selectedClipId, moveClip, addTrack, removeTrack,
    splitClip, tool, undo, redo,
  } = useEditorStore()

  const scrollRef   = useRef<HTMLDivElement>(null)
  const rulerRef    = useRef<HTMLDivElement>(null)
  const [drag, setDrag] = useState<DragState | null>(null)

  const PX = 80 * zoom
  const duration   = Math.max(timeline.duration || 120, 1)
  const totalWidth = Math.max(duration * PX + 300, 1000)

  const t2x  = useCallback((t: number) => t * PX, [PX])
  const x2t  = useCallback((x: number) => Math.max(0, x / PX), [PX])

  function seekFromRuler(e: React.MouseEvent<HTMLDivElement>) {
    const rect = e.currentTarget.getBoundingClientRect()
    const sl   = scrollRef.current?.scrollLeft ?? 0
    setCurrentTime(x2t(e.clientX - rect.left + sl))
  }

  function onClipDown(e: React.MouseEvent, clip: Clip, trackId: string) {
    e.stopPropagation()
    selectClip(clip.id)

    if (tool === 'cut') {
      splitClip(trackId, clip.id, currentTime)
      toast.success('Clip split at playhead')
      return
    }

    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect()
    const clickXInClip = e.clientX - rect.left
    setDrag({ clipId: clip.id, trackId, offsetSec: x2t(clickXInClip) })
  }

  function onMouseMove(e: React.MouseEvent<HTMLDivElement>) {
    if (!drag) return
    const container = e.currentTarget.getBoundingClientRect()
    const sl        = scrollRef.current?.scrollLeft ?? 0
    const rawX      = e.clientX - container.left + sl - t2x(drag.offsetSec) - 80 // 80 = label width
    const snapped   = Math.round(Math.max(0, x2t(rawX)) * 10) / 10
    moveClip(drag.trackId, drag.trackId, drag.clipId, snapped)
  }

  // Ruler tick marks
  const step  = zoom < 0.6 ? 60 : zoom < 1 ? 30 : zoom < 2 ? 10 : zoom < 4 ? 5 : 1
  const marks = []
  for (let t = 0; t <= duration + step; t += step) {
    const m = Math.floor(t / 60), s = t % 60
    marks.push({ t, label: `${m}:${String(s).padStart(2, '0')}` })
  }

  const playheadLeft = t2x(currentTime)

  return (
    <div className="h-[210px] bg-scarface-surface border-t border-scarface-border flex flex-col shrink-0">
      {/* Toolbar */}
      <div className="h-9 flex items-center justify-between px-3 border-b border-scarface-border shrink-0 gap-2">
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-[10px] font-semibold text-scarface-dim uppercase tracking-widest mr-1 hidden sm:block">Timeline</span>
          <button onClick={undo} title="Undo (⌘Z)" className="btn-ghost text-xs px-2 py-1">↩</button>
          <button onClick={redo} title="Redo"      className="btn-ghost text-xs px-2 py-1">↪</button>
          <div className="w-px h-4 bg-scarface-border mx-0.5" />
          <button onClick={() => addTrack('video')}   className="btn-ghost text-xs px-2 py-1">+ Video</button>
          <button onClick={() => addTrack('audio')}   className="btn-ghost text-xs px-2 py-1">+ Audio</button>
          <button onClick={() => addTrack('text')}    className="btn-ghost text-xs px-2 py-1">+ Text</button>
          <button onClick={() => addTrack('effect')}  className="btn-ghost text-xs px-2 py-1 hidden sm:flex">+ FX</button>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <span className="text-[10px] text-scarface-dim hidden sm:block">Zoom</span>
          <input type="range" min={0.3} max={6} step={0.1} value={zoom}
            onChange={e => setZoom(Number(e.target.value))} className="w-20" />
          <span className="text-[10px] text-scarface-muted font-mono w-8 text-right">{zoom.toFixed(1)}×</span>
        </div>
      </div>

      {/* Body */}
      <div
        className="flex flex-1 overflow-hidden cursor-default"
        onMouseMove={onMouseMove}
        onMouseUp={() => setDrag(null)}
        onMouseLeave={() => setDrag(null)}
      >
        {/* Track labels */}
        <div className="w-20 bg-scarface-bg border-r border-scarface-border shrink-0 flex flex-col">
          {/* Ruler spacer */}
          <div className="h-5 border-b border-scarface-border shrink-0 bg-scarface-surface" />
          {timeline.tracks.map(track => (
            <div key={track.id}
              className="flex items-center gap-1.5 px-2 border-b border-scarface-border/40 shrink-0 group relative"
              style={{ height: TRACK_H }}>
              <span className="text-[11px] shrink-0">{TRACK_ICONS[track.type] ?? '▪'}</span>
              <span className="text-[10px] truncate text-scarface-dim flex-1">{track.name}</span>
              <button
                onClick={() => { if (timeline.tracks.length > 1) removeTrack(track.id); else toast.error("Can't remove last track") }}
                className="absolute right-1 text-[9px] text-scarface-dim opacity-0 group-hover:opacity-100 hover:text-red-400 transition-all w-4 h-4 flex items-center justify-center"
                title="Remove track"
              >×</button>
            </div>
          ))}
        </div>

        {/* Scrollable area */}
        <div ref={scrollRef} className="flex-1 overflow-x-auto overflow-y-hidden relative">
          <div style={{ width: totalWidth, position: 'relative', minHeight: '100%' }}>

            {/* Ruler */}
            <div ref={rulerRef} onClick={seekFromRuler}
              className="h-5 bg-scarface-surface border-b border-scarface-border cursor-pointer sticky top-0 z-10 relative select-none shrink-0">
              {marks.map(({ t, label }) => (
                <div key={t} className="absolute flex flex-col items-start" style={{ left: t2x(t) }}>
                  <div className="w-px h-2 bg-scarface-border/70" />
                  <span className="text-[9px] text-scarface-dim leading-none pl-0.5">{label}</span>
                </div>
              ))}
            </div>

            {/* Track rows */}
            {timeline.tracks.map(track => (
              <div key={track.id}
                className="relative border-b border-scarface-border/30 bg-scarface-bg/50"
                style={{ height: TRACK_H }}>
                {track.clips.map(clip => (
                  <ClipBlock
                    key={clip.id}
                    clip={clip}
                    track={track}
                    left={t2x(clip.startTime)}
                    width={Math.max(t2x(clip.duration), 8)}
                    selected={clip.id === selectedClipId}
                    dragging={drag?.clipId === clip.id}
                    onMouseDown={onClipDown}
                    trackType={track.type}
                  />
                ))}
              </div>
            ))}

            {/* Playhead */}
            <div
              className="absolute top-0 bottom-0 pointer-events-none z-20"
              style={{ left: playheadLeft }}
            >
              <div className="absolute top-0 w-px h-full bg-scarface-accent opacity-90" />
              <div className="absolute -top-0 left-1/2 -translate-x-1/2 w-2.5 h-2.5 rounded-full bg-scarface-accent" />
            </div>

            {/* Empty state row hints */}
            {timeline.tracks.every(t => t.clips.length === 0) && (
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none" style={{ top: 20 }}>
                <span className="text-xs text-scarface-dim/40 italic">Add clips from the media panel →</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

function ClipBlock({ clip, track, left, width, selected, dragging, onMouseDown, trackType }: {
  clip: Clip; track: Track; left: number; width: number
  selected: boolean; dragging: boolean
  onMouseDown: (e: React.MouseEvent, clip: Clip, trackId: string) => void
  trackType: string
}) {
  const colors = TRACK_COLORS[trackType] ?? TRACK_COLORS.video
  return (
    <div
      onMouseDown={e => onMouseDown(e, clip, track.id)}
      className={`
        absolute top-1 rounded border flex items-center px-2 overflow-hidden
        cursor-grab active:cursor-grabbing select-none transition-all duration-75
        ${colors.bg} ${colors.border} ${colors.hover}
        ${selected ? '!border-white/70 ring-1 ring-white/25 brightness-110' : ''}
        ${dragging ? 'opacity-70 scale-y-95' : ''}
      `}
      style={{ left, width, height: TRACK_H - 8 }}
      title={clip.name}
    >
      {/* Waveform background for audio */}
      {trackType === 'audio' && (
        <div className="absolute inset-0 flex items-center px-1 opacity-30 pointer-events-none">
          {Array.from({ length: Math.floor(width / 4) }, (_, i) => (
            <div key={i} className="w-px bg-emerald-300 mx-px"
              style={{ height: `${30 + Math.sin(i * 1.7 + parseInt(clip.id.slice(-4), 16)) * 25}%` }} />
          ))}
        </div>
      )}

      <span className="text-[10px] text-white/80 truncate relative z-10 leading-none select-none font-medium">
        {clip.name}
      </span>

      {/* Duration badge */}
      {width > 60 && (
        <span className="absolute right-1.5 text-[9px] text-white/40 tabular-nums">
          {clip.duration.toFixed(1)}s
        </span>
      )}

      {/* Trim handles */}
      <div className="absolute left-0 top-0 bottom-0 w-1.5 cursor-ew-resize hover:bg-white/20 rounded-l transition-colors" />
      <div className="absolute right-0 top-0 bottom-0 w-1.5 cursor-ew-resize hover:bg-white/20 rounded-r transition-colors" />
    </div>
  )
}
