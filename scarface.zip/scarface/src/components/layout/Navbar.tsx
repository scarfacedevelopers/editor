'use client'
import Link from 'next/link'
import { useSession, signOut } from 'next-auth/react'

export default function Navbar() {
  const { data: session } = useSession()

  return (
    <nav className="border-b border-scarface-border bg-scarface-surface/80 backdrop-blur-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-6 py-3 flex items-center justify-between">
        <Link href={session ? '/dashboard' : '/'} className="flex items-center gap-2">
          <div className="w-8 h-8 bg-scarface-accent rounded-lg flex items-center justify-center text-white font-display font-bold text-sm">S</div>
          <span className="font-display font-bold text-xl tracking-tight text-scarface-text">SCARFACE</span>
        </Link>

        <div className="flex items-center gap-3">
          {session ? (
            <>
              <span className="text-scarface-muted text-sm hidden sm:block">{session.user?.name}</span>
              <Link href="/dashboard" className="btn-ghost text-sm px-3 py-1.5">Dashboard</Link>
              <button onClick={() => signOut({ callbackUrl: '/' })} className="btn-ghost text-sm px-3 py-1.5">Sign out</button>
            </>
          ) : (
            <>
              <Link href="/login"  className="btn-ghost text-sm px-4 py-2">Sign in</Link>
              <Link href="/signup" className="btn-primary text-sm px-4 py-2">Get started</Link>
            </>
          )}
        </div>
      </div>
    </nav>
  )
}
