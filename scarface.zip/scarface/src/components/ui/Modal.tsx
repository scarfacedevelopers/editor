'use client'
import { useEffect } from 'react'

interface Props {
  open:      boolean
  onClose:   () => void
  title?:    string
  children:  React.ReactNode
  maxWidth?: string
}

export default function Modal({ open, onClose, title, children, maxWidth = 'max-w-md' }: Props) {
  useEffect(() => {
    if (!open) return
    function onKey(e: KeyboardEvent) { if (e.key === 'Escape') onClose() }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open, onClose])

  if (!open) return null

  return (
    <div
      className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center px-4"
      onClick={e => { if (e.target === e.currentTarget) onClose() }}
    >
      <div className={`bg-scarface-card border border-scarface-border rounded-2xl p-8 w-full ${maxWidth} shadow-2xl animate-slide-up`}>
        {title && (
          <div className="flex items-center justify-between mb-6">
            <h2 className="font-display font-bold text-xl text-scarface-text">{title}</h2>
            <button onClick={onClose} className="text-scarface-dim hover:text-scarface-text text-xl leading-none transition-colors">×</button>
          </div>
        )}
        {children}
      </div>
    </div>
  )
}
