'use client'
import { useEffect, useRef } from 'react'
import { generateWaveformData } from '@/lib/utils'

interface Props {
  width:    number
  height:   number
  color?:   string
  seed?:    string
}

export default function Waveform({ width, height, color = '#00b894', seed = 'default' }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    // Seeded deterministic waveform
    const points = generateWaveformData(Math.floor(width / 3))
    ctx.clearRect(0, 0, width, height)

    const mid  = height / 2
    const step = width / points.length

    ctx.strokeStyle = color
    ctx.lineWidth   = 1.5
    ctx.globalAlpha = 0.85

    for (let i = 0; i < points.length; i++) {
      const x   = i * step
      const amp = points[i] * mid
      ctx.beginPath()
      ctx.moveTo(x, mid - amp)
      ctx.lineTo(x, mid + amp)
      ctx.stroke()
    }
  }, [width, height, color, seed])

  return <canvas ref={canvasRef} width={width} height={height} className="waveform-canvas w-full h-full" />
}
