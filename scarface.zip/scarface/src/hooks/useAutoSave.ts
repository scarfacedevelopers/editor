'use client'
import { useEffect, useRef, useState } from 'react'
import { Timeline } from '@/types'

type SaveStatus = 'saved' | 'saving' | 'unsaved' | 'error'

export function useAutoSave(projectId: string, timeline: Timeline, delay = 2000) {
  const [status, setStatus]   = useState<SaveStatus>('saved')
  const timerRef              = useRef<ReturnType<typeof setTimeout>>()
  const prevTimelineRef       = useRef<string>('')

  useEffect(() => {
    const serialized = JSON.stringify(timeline)
    if (serialized === prevTimelineRef.current) return
    prevTimelineRef.current = serialized
    setStatus('unsaved')

    clearTimeout(timerRef.current)
    timerRef.current = setTimeout(async () => {
      setStatus('saving')
      try {
        const res = await fetch(`/api/projects/${projectId}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ timeline }),
        })
        setStatus(res.ok ? 'saved' : 'error')
      } catch {
        setStatus('error')
      }
    }, delay)

    return () => clearTimeout(timerRef.current)
  }, [timeline, projectId, delay])

  async function saveNow() {
    clearTimeout(timerRef.current)
    setStatus('saving')
    try {
      const res = await fetch(`/api/projects/${projectId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ timeline }),
      })
      setStatus(res.ok ? 'saved' : 'error')
      return res.ok
    } catch {
      setStatus('error')
      return false
    }
  }

  return { status, saveNow }
}
