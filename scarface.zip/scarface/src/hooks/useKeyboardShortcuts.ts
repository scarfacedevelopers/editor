'use client'
import { useEffect } from 'react'
import { useEditorStore } from '@/store/editor'
import toast from 'react-hot-toast'

export function useKeyboardShortcuts(onSave: () => void) {
  const { setPlaying, playing, undo, redo, setTool, splitClip,
          selectedClipId, timeline, currentTime, removeClip } = useEditorStore()

  useEffect(() => {
    function handler(e: KeyboardEvent) {
      const tag = (e.target as HTMLElement)?.tagName
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return

      const ctrl = e.metaKey || e.ctrlKey

      // Save
      if (ctrl && e.key === 's') { e.preventDefault(); onSave(); return }
      // Undo/redo
      if (ctrl && e.key === 'z') { e.preventDefault(); e.shiftKey ? redo() : undo(); return }
      if (ctrl && e.key === 'y') { e.preventDefault(); redo(); return }

      // Playback
      if (e.key === ' ') { e.preventDefault(); setPlaying(!playing); return }

      // Tool shortcuts
      if (e.key === 'v' || e.key === 'V') setTool('select')
      if (e.key === 'c' || e.key === 'C') setTool('cut')
      if (e.key === 't' || e.key === 'T') setTool('text')
      if (e.key === 'z' || e.key === 'Z') setTool('zoom')

      // Delete selected clip
      if ((e.key === 'Delete' || e.key === 'Backspace') && selectedClipId) {
        for (const track of timeline.tracks) {
          if (track.clips.find(c => c.id === selectedClipId)) {
            removeClip(track.id, selectedClipId)
            toast.success('Clip deleted')
            break
          }
        }
      }

      // Split clip at playhead
      if (e.key === 's' && !ctrl && selectedClipId) {
        for (const track of timeline.tracks) {
          const clip = track.clips.find(c => c.id === selectedClipId)
          if (clip) { splitClip(track.id, selectedClipId, currentTime); toast.success('Clip split'); break }
        }
      }
    }

    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [playing, selectedClipId, currentTime, timeline, undo, redo, onSave,
      setPlaying, setTool, splitClip, removeClip])
}
