'use client'
import { useState, useEffect, useCallback } from 'react'
import { Project } from '@/types'
import toast from 'react-hot-toast'

export function useProjects() {
  const [projects, setProjects] = useState<Project[]>([])
  const [loading, setLoading]   = useState(true)
  const [error, setError]       = useState<string | null>(null)

  const fetch_ = useCallback(async () => {
    setLoading(true)
    try {
      const res  = await fetch('/api/projects')
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      setProjects(data.projects)
    } catch (e: any) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { fetch_() }, [fetch_])

  async function create(name: string, resolution = '1080p', fps = 30) {
    const res  = await fetch('/api/projects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, resolution, fps }),
    })
    const data = await res.json()
    if (!res.ok) { toast.error(data.error); return null }
    setProjects(p => [data.project, ...p])
    return data.project as Project
  }

  async function remove(id: string) {
    const res = await fetch(`/api/projects/${id}`, { method: 'DELETE' })
    if (res.ok) {
      setProjects(p => p.filter(x => x.id !== id))
      toast.success('Project deleted')
    } else {
      toast.error('Delete failed')
    }
  }

  async function save(id: string, updates: Partial<Project>) {
    const res  = await fetch(`/api/projects/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates),
    })
    const data = await res.json()
    if (!res.ok) { toast.error('Save failed'); return null }
    setProjects(p => p.map(x => x.id === id ? data.project : x))
    return data.project as Project
  }

  return { projects, loading, error, refetch: fetch_, create, remove, save }
}

export function useProject(id: string) {
  const [project, setProject] = useState<Project | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!id) return
    fetch(`/api/projects/${id}`)
      .then(r => r.json())
      .then(d => { setProject(d.project ?? null); setLoading(false) })
      .catch(() => setLoading(false))
  }, [id])

  return { project, loading }
}
