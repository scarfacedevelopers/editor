import { type ClassValue, clsx } from 'clsx'

export function cn(...inputs: ClassValue[]) {
  return clsx(inputs)
}

export function formatTime(seconds: number): string {
  const m   = Math.floor(seconds / 60)
  const s   = Math.floor(seconds % 60)
  const ms  = Math.floor((seconds % 1) * 100)
  return `${m}:${String(s).padStart(2, '0')}.${String(ms).padStart(2, '0')}`
}

export function formatDuration(seconds: number): string {
  const m = Math.floor(seconds / 60)
  const s = Math.floor(seconds % 60)
  return `${m}:${String(s).padStart(2, '0')}`
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024)       return `${bytes} B`
  if (bytes < 1048576)    return `${(bytes / 1024).toFixed(1)} KB`
  if (bytes < 1073741824) return `${(bytes / 1048576).toFixed(1)} MB`
  return `${(bytes / 1073741824).toFixed(2)} GB`
}

export function clamp(value: number, min: number, max: number): number {
  return Math.min(Math.max(value, min), max)
}

export function snapToGrid(value: number, grid: number): number {
  return Math.round(value / grid) * grid
}

export function getMediaType(file: File): 'video' | 'audio' | 'image' | null {
  if (file.type.startsWith('video/'))  return 'video'
  if (file.type.startsWith('audio/'))  return 'audio'
  if (file.type.startsWith('image/'))  return 'image'
  return null
}

export function generateWaveformData(length = 100): number[] {
  return Array.from({ length }, () => Math.random() * 0.8 + 0.1)
}
