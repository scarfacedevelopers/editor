import { create } from 'zustand'
import { Track, Clip, Timeline, Project, ExportSettings } from '@/types'
import { v4 as uuid } from 'uuid'

interface EditorState {
  project: Project | null
  timeline: Timeline
  selectedClipId: string | null
  selectedTrackId: string | null
  currentTime: number
  playing: boolean
  zoom: number
  volume: number
  muted: boolean
  playbackSpeed: number
  tool: 'select' | 'cut' | 'text' | 'zoom'
  panel: 'media' | 'text' | 'effects' | 'transitions' | 'audio' | 'filters' | 'ai'
  exportSettings: ExportSettings
  history: Timeline[]
  historyIndex: number
  setProject: (p: Project) => void
  setCurrentTime: (fn: number | ((prev: number) => number)) => void
  setPlaying: (v: boolean) => void
  setZoom: (z: number) => void
  setVolume: (v: number) => void
  setMuted: (v: boolean) => void
  setTool: (t: EditorState['tool']) => void
  setPanel: (p: EditorState['panel']) => void
  selectClip: (id: string | null) => void
  selectTrack: (id: string | null) => void
  addTrack: (type: Track['type']) => void
  removeTrack: (id: string) => void
  addClip: (trackId: string, clip: Omit<Clip, 'id'>) => void
  updateClip: (trackId: string, clipId: string, updates: Partial<Clip>) => void
  removeClip: (trackId: string, clipId: string) => void
  moveClip: (fromTrack: string, toTrack: string, clipId: string, newStart: number) => void
  splitClip: (trackId: string, clipId: string, at: number) => void
  updateTimeline: (t: Partial<Timeline>) => void
  setExportSettings: (s: Partial<ExportSettings>) => void
  undo: () => void
  redo: () => void
  pushHistory: () => void
}

const makeDefaultTimeline = (): Timeline => ({
  tracks: [
    { id: uuid(), type: 'video', name: 'Video 1', muted: false, solo: false, clips: [], volume: 1, color: '#6c5ce7' },
    { id: uuid(), type: 'video', name: 'Video 2', muted: false, solo: false, clips: [], volume: 1, color: '#a29bfe' },
    { id: uuid(), type: 'audio', name: 'Audio 1', muted: false, solo: false, clips: [], volume: 1, color: '#00b894' },
    { id: uuid(), type: 'text', name: 'Captions', muted: false, solo: false, clips: [], volume: 1, color: '#fdcb6e' },
    { id: uuid(), type: 'effect', name: 'Effects', muted: false, solo: false, clips: [], volume: 1, color: '#e17055' },
  ],
  duration: 120,
  fps: 30,
})

export const useEditorStore = create<EditorState>((set, get) => ({
  project: null,
  timeline: makeDefaultTimeline(),
  selectedClipId: null,
  selectedTrackId: null,
  currentTime: 0,
  playing: false,
  zoom: 1,
  volume: 0.8,
  muted: false,
  playbackSpeed: 1,
  tool: 'select',
  panel: 'media',
  exportSettings: { resolution: '1080p', format: 'mp4', quality: 85, fps: 30 },
  history: [],
  historyIndex: -1,

  setProject: (p) => set({ project: p, timeline: p.timeline }),
  setCurrentTime: (fn) => set(s => ({ currentTime: typeof fn === 'function' ? fn(s.currentTime) : fn })),
  setPlaying: (v) => set({ playing: v }),
  setZoom: (z) => set({ zoom: Math.max(0.3, Math.min(6, z)) }),
  setVolume: (v) => set({ volume: v }),
  setMuted: (v) => set({ muted: v }),
  setTool: (t) => set({ tool: t }),
  setPanel: (p) => set({ panel: p }),
  selectClip: (id) => set({ selectedClipId: id }),
  selectTrack: (id) => set({ selectedTrackId: id }),

  addTrack: (type) => set(s => ({
    timeline: {
      ...s.timeline,
      tracks: [...s.timeline.tracks, {
        id: uuid(), type,
        name: `${type.charAt(0).toUpperCase() + type.slice(1)} ${s.timeline.tracks.length + 1}`,
        muted: false, solo: false, clips: [], volume: 1, color: '#6c5ce7',
      }],
    },
  })),

  removeTrack: (id) => set(s => ({
    timeline: { ...s.timeline, tracks: s.timeline.tracks.filter(t => t.id !== id) },
  })),

  addClip: (trackId, clip) => set(s => ({
    timeline: {
      ...s.timeline,
      tracks: s.timeline.tracks.map(t =>
        t.id === trackId ? { ...t, clips: [...t.clips, { ...clip, id: uuid() }] } : t
      ),
    },
  })),

  updateClip: (trackId, clipId, updates) => set(s => ({
    timeline: {
      ...s.timeline,
      tracks: s.timeline.tracks.map(t =>
        t.id !== trackId ? t : { ...t, clips: t.clips.map(c => c.id === clipId ? { ...c, ...updates } : c) }
      ),
    },
  })),

  removeClip: (trackId, clipId) => set(s => ({
    timeline: {
      ...s.timeline,
      tracks: s.timeline.tracks.map(t =>
        t.id !== trackId ? t : { ...t, clips: t.clips.filter(c => c.id !== clipId) }
      ),
    },
    selectedClipId: s.selectedClipId === clipId ? null : s.selectedClipId,
  })),

  moveClip: (fromTrack, toTrack, clipId, newStart) => set(s => {
    const src = s.timeline.tracks.find(t => t.id === fromTrack)
    const clip = src?.clips.find(c => c.id === clipId)
    if (!clip) return {}
    const snapped = Math.max(0, Math.round(newStart * 10) / 10)
    if (fromTrack === toTrack) {
      return {
        timeline: {
          ...s.timeline,
          tracks: s.timeline.tracks.map(t =>
            t.id !== fromTrack ? t : { ...t, clips: t.clips.map(c => c.id === clipId ? { ...c, startTime: snapped } : c) }
          ),
        },
      }
    }
    return {
      timeline: {
        ...s.timeline,
        tracks: s.timeline.tracks.map(t => {
          if (t.id === fromTrack) return { ...t, clips: t.clips.filter(c => c.id !== clipId) }
          if (t.id === toTrack) return { ...t, clips: [...t.clips, { ...clip, startTime: snapped, trackId: toTrack }] }
          return t
        }),
      },
    }
  }),

  splitClip: (trackId, clipId, at) => set(s => {
    const track = s.timeline.tracks.find(t => t.id === trackId)
    const clip = track?.clips.find(c => c.id === clipId)
    if (!clip || at <= clip.startTime || at >= clip.startTime + clip.duration) return {}
    const leftDur = at - clip.startTime
    const rightDur = clip.duration - leftDur
    return {
      timeline: {
        ...s.timeline,
        tracks: s.timeline.tracks.map(t =>
          t.id !== trackId ? t : {
            ...t,
            clips: t.clips.flatMap(c => c.id !== clipId ? [c] : [
              { ...c, duration: leftDur },
              { ...c, id: uuid(), startTime: at, duration: rightDur, trimStart: c.trimStart + leftDur },
            ]),
          }
        ),
      },
    }
  }),

  updateTimeline: (t) => set(s => ({ timeline: { ...s.timeline, ...t } })),
  setExportSettings: (es) => set(s => ({ exportSettings: { ...s.exportSettings, ...es } })),

  pushHistory: () => set(s => {
    const tl = JSON.parse(JSON.stringify(s.timeline))
    const hist = s.history.slice(0, s.historyIndex + 1)
    return { history: [...hist, tl], historyIndex: hist.length }
  }),

  undo: () => set(s => {
    if (s.historyIndex <= 0) return {}
    const idx = s.historyIndex - 1
    return { historyIndex: idx, timeline: JSON.parse(JSON.stringify(s.history[idx])) }
  }),

  redo: () => set(s => {
    if (s.historyIndex >= s.history.length - 1) return {}
    const idx = s.historyIndex + 1
    return { historyIndex: idx, timeline: JSON.parse(JSON.stringify(s.history[idx])) }
  }),
}))
