export type Resolution = '720p' | '1080p' | '4K'
export type MediaType  = 'video' | 'audio' | 'image'
export type TrackType  = 'video' | 'audio' | 'text' | 'effect' | 'overlay'
export type ExportFormat = 'mp4' | 'mov' | 'webm' | 'gif'
export type ProjectStatus = 'draft' | 'rendering' | 'exported' | 'archived'

export interface MediaFile {
  id:        string
  name:      string
  type:      MediaType
  url:       string
  size:      number
  duration?: number
  width?:    number
  height?:   number
  thumbnail?:string
  projectId: string
  createdAt: string
}

export interface Clip {
  id:         string
  mediaId?:   string
  trackId:    string
  startTime:  number   // seconds on timeline
  duration:   number   // seconds
  trimStart:  number   // trim in seconds from media start
  trimEnd:    number   // trim in seconds from media end
  volume:     number   // 0-1
  opacity:    number   // 0-1
  speed:      number   // 0.25-4
  filters:    ClipFilter[]
  effects:    string[]
  text?:      TextClip
  transform:  Transform
  name:       string
}

export interface TextClip {
  content:   string
  fontSize:  number
  fontFamily:string
  color:     string
  bold:      boolean
  italic:    boolean
  align:     'left' | 'center' | 'right'
  preset?:   string
}

export interface Transform {
  x:       number
  y:       number
  scaleX:  number
  scaleY:  number
  rotation:number
}

export interface ClipFilter {
  type:      string
  intensity: number
}

export interface Track {
  id:    string
  type:  TrackType
  name:  string
  muted: boolean
  solo:  boolean
  clips: Clip[]
  volume:number
  color: string
}

export interface Timeline {
  tracks:   Track[]
  duration: number
  fps:      number
}

export interface Project {
  id:         string
  name:       string
  description?:string
  thumbnail?: string
  duration:   number
  resolution: Resolution
  fps:        number
  status:     ProjectStatus
  timeline:   Timeline
  mediaFiles: MediaFile[]
  userId:     string
  createdAt:  string
  updatedAt:  string
}

export interface ExportSettings {
  resolution: Resolution
  format:     ExportFormat
  quality:    number
  fps:        number
}
