/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['var(--font-display)', 'serif'],
        body: ['var(--font-body)', 'sans-serif'],
        mono: ['var(--font-mono)', 'monospace'],
      },
      colors: {
        scarface: {
          bg:      '#080a0e',
          surface: '#0f1117',
          card:    '#141720',
          border:  '#1e2333',
          hover:   '#252b3b',
          accent:  '#e63946',
          gold:    '#f4a261',
          teal:    '#2ec4b6',
          text:    '#e8eaf0',
          muted:   '#6b7280',
          dim:     '#3d4460',
        },
      },
      animation: {
        'fade-in':    'fadeIn .3s ease',
        'slide-up':   'slideUp .3s ease',
        'pulse-slow': 'pulse 3s ease-in-out infinite',
        'spin-slow':  'spin 8s linear infinite',
      },
      keyframes: {
        fadeIn:  { from: { opacity: 0 }, to: { opacity: 1 } },
        slideUp: { from: { opacity: 0, transform: 'translateY(12px)' }, to: { opacity: 1, transform: 'translateY(0)' } },
      },
    },
  },
  plugins: [],
}
